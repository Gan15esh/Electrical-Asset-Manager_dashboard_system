// API client utilities for making requests to backend APIs

interface FetchOptions extends RequestInit {
  params?: Record<string, string>
}

class APIClient {
  private baseURL: string

  constructor() {
    this.baseURL = process.env.NEXT_PUBLIC_API_URL || ""
  }

  private async request<T>(endpoint: string, options: FetchOptions = {}): Promise<T> {
    const { params, ...fetchOptions } = options

    // Build URL with query parameters
    let url = `${this.baseURL}${endpoint}`
    if (params) {
      const searchParams = new URLSearchParams(params)
      url += `?${searchParams.toString()}`
    }

    const response = await fetch(url, {
      ...fetchOptions,
      headers: {
        "Content-Type": "application/json",
        ...fetchOptions.headers,
      },
    })

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: "An error occurred" }))
      throw new Error(error.error || `HTTP error! status: ${response.status}`)
    }

    return response.json()
  }

  // Products API
  async getProducts(filters?: { category?: string; supplier?: string; status?: string }) {
    return this.request("/api/products", { params: filters as Record<string, string> })
  }

  async getProduct(id: string) {
    return this.request(`/api/products/${id}`)
  }

  async createProduct(data: any) {
    return this.request("/api/products", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updateProduct(id: string, data: any) {
    return this.request(`/api/products/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async deleteProduct(id: string) {
    return this.request(`/api/products/${id}`, {
      method: "DELETE",
    })
  }

  async getProductStats() {
    return this.request("/api/products/stats")
  }

  // Warranties API
  async getWarranties(filters?: { status?: string; supplier?: string }) {
    return this.request("/api/warranties", { params: filters as Record<string, string> })
  }

  async getWarranty(id: string) {
    return this.request(`/api/warranties/${id}`)
  }

  async createWarranty(data: any) {
    return this.request("/api/warranties", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updateWarranty(id: string, data: any) {
    return this.request(`/api/warranties/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async deleteWarranty(id: string) {
    return this.request(`/api/warranties/${id}`, {
      method: "DELETE",
    })
  }

  async getWarrantyStats() {
    return this.request("/api/warranties/stats")
  }

  // Invoices API
  async getInvoices(filters?: { status?: string; supplier?: string }) {
    return this.request("/api/invoices", { params: filters as Record<string, string> })
  }

  async getInvoice(id: string) {
    return this.request(`/api/invoices/${id}`)
  }

  async createInvoice(data: any) {
    return this.request("/api/invoices", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updateInvoice(id: string, data: any) {
    return this.request(`/api/invoices/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async deleteInvoice(id: string) {
    return this.request(`/api/invoices/${id}`, {
      method: "DELETE",
    })
  }

  async getInvoiceStats() {
    return this.request("/api/invoices/stats")
  }

  // Payments API
  async getPayments(filters?: { status?: string; supplier?: string; invoice_id?: string }) {
    return this.request("/api/payments", { params: filters as Record<string, string> })
  }

  async getPayment(id: string) {
    return this.request(`/api/payments/${id}`)
  }

  async createPayment(data: any) {
    return this.request("/api/payments", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updatePayment(id: string, data: any) {
    return this.request(`/api/payments/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async deletePayment(id: string) {
    return this.request(`/api/payments/${id}`, {
      method: "DELETE",
    })
  }

  async getPaymentStats() {
    return this.request("/api/payments/stats")
  }
}

export const apiClient = new APIClient()
