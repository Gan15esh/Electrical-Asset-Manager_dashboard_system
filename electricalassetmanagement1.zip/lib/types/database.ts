export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: number
          email: string
          password_hash: string
          full_name: string | null
          company_name: string | null
          phone: string | null
          role: "admin" | "user"
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          email: string
          password_hash: string
          full_name?: string | null
          company_name?: string | null
          phone?: string | null
          role?: "admin" | "user"
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          email?: string
          password_hash?: string
          full_name?: string | null
          company_name?: string | null
          phone?: string | null
          role?: "admin" | "user"
          updated_at?: string
        }
      }
      products: {
        Row: {
          id: number
          user_id: number
          name: string
          category: string | null
          model_number: string | null
          serial_number: string | null
          manufacturer: string | null
          purchase_date: string | null
          purchase_price: number | null
          location: string | null
          status: "active" | "inactive" | "maintenance" | "retired"
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          user_id: number
          name: string
          category?: string | null
          model_number?: string | null
          serial_number?: string | null
          manufacturer?: string | null
          purchase_date?: string | null
          purchase_price?: number | null
          location?: string | null
          status?: "active" | "inactive" | "maintenance" | "retired"
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          user_id?: number
          name?: string
          category?: string | null
          model_number?: string | null
          serial_number?: string | null
          manufacturer?: string | null
          purchase_date?: string | null
          purchase_price?: number | null
          location?: string | null
          status?: "active" | "inactive" | "maintenance" | "retired"
          notes?: string | null
          updated_at?: string
        }
      }
      warranties: {
        Row: {
          id: number
          user_id: number
          product_id: number | null
          warranty_number: string | null
          provider: string | null
          start_date: string
          end_date: string
          coverage_type: string | null
          terms: string | null
          status: "active" | "expired" | "claimed"
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          user_id: number
          product_id?: number | null
          warranty_number?: string | null
          provider?: string | null
          start_date: string
          end_date: string
          coverage_type?: string | null
          terms?: string | null
          status?: "active" | "expired" | "claimed"
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          user_id?: number
          product_id?: number | null
          warranty_number?: string | null
          provider?: string | null
          start_date?: string
          end_date?: string
          coverage_type?: string | null
          terms?: string | null
          status?: "active" | "expired" | "claimed"
          updated_at?: string
        }
      }
      invoices: {
        Row: {
          id: number
          user_id: number
          invoice_number: string
          customer_name: string | null
          customer_email: string | null
          issue_date: string
          due_date: string
          subtotal: number
          tax: number
          total: number
          status: "draft" | "sent" | "paid" | "overdue" | "cancelled"
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          user_id: number
          invoice_number: string
          customer_name?: string | null
          customer_email?: string | null
          issue_date: string
          due_date: string
          subtotal: number
          tax?: number
          status?: "draft" | "sent" | "paid" | "overdue" | "cancelled"
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          user_id?: number
          invoice_number?: string
          customer_name?: string | null
          customer_email?: string | null
          issue_date?: string
          due_date?: string
          subtotal?: number
          tax?: number
          status?: "draft" | "sent" | "paid" | "overdue" | "cancelled"
          notes?: string | null
          updated_at?: string
        }
      }
      invoice_items: {
        Row: {
          id: number
          invoice_id: number
          product_id: number | null
          description: string
          quantity: number
          unit_price: number
          total: number
          created_at: string
        }
        Insert: {
          id?: number
          invoice_id: number
          product_id?: number | null
          description: string
          quantity: number
          unit_price: number
          total: number
          created_at?: string
        }
        Update: {
          id?: number
          invoice_id?: number
          product_id?: number | null
          description?: string
          quantity?: number
          unit_price?: number
          total?: number
          updated_at?: string
        }
      }
      payments: {
        Row: {
          id: number
          user_id: number
          invoice_id: number | null
          payment_date: string
          amount: number
          payment_method: "cash" | "credit_card" | "debit_card" | "bank_transfer" | "cheque" | "other"
          reference_number: string | null
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          user_id: number
          invoice_id?: number | null
          payment_date: string
          amount: number
          payment_method: "cash" | "credit_card" | "debit_card" | "bank_transfer" | "cheque" | "other"
          reference_number?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          user_id?: number
          invoice_id?: number | null
          payment_date?: string
          amount?: number
          payment_method?: "cash" | "credit_card" | "debit_card" | "bank_transfer" | "cheque" | "other"
          reference_number?: string | null
          notes?: string | null
          updated_at?: string
        }
      }
      maintenance_records: {
        Row: {
          id: number
          user_id: number
          product_id: number
          maintenance_date: string
          maintenance_type: "preventive" | "corrective" | "inspection" | "calibration"
          technician: string | null
          description: string | null
          cost: number | null
          next_maintenance_date: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          user_id: number
          product_id: number
          maintenance_date: string
          maintenance_type: "preventive" | "corrective" | "inspection" | "calibration"
          technician?: string | null
          description?: string | null
          cost?: number | null
          next_maintenance_date?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          user_id?: number
          product_id?: number
          maintenance_date?: string
          maintenance_type?: "preventive" | "corrective" | "inspection" | "calibration"
          technician?: string | null
          description?: string | null
          cost?: number | null
          next_maintenance_date?: string | null
          updated_at?: string
        }
      }
    }
  }
}
