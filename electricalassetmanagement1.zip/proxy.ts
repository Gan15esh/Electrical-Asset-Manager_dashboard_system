import { NextResponse, type NextRequest } from "next/server"
import { verifyToken } from "@/lib/auth/jwt"

export async function proxy(request: NextRequest) {
  const token = request.cookies.get("auth_token")?.value
  const user = token ? verifyToken(token) : null

  // Protected routes
  const protectedRoutes = ["/dashboard", "/products", "/warranties", "/invoices", "/payments"]
  const isProtectedRoute = protectedRoutes.some((route) => request.nextUrl.pathname.startsWith(route))

  if (isProtectedRoute && !user) {
    const url = request.nextUrl.clone()
    url.pathname = "/login"
    return NextResponse.redirect(url)
  }

  if ((request.nextUrl.pathname === "/login" || request.nextUrl.pathname === "/signup") && user) {
    const url = request.nextUrl.clone()
    url.pathname = "/dashboard"
    return NextResponse.redirect(url)
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
}
