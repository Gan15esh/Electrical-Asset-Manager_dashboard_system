# MySQL Backend Setup Guide

This guide will help you set up MySQL on a separate PC and connect your Next.js application to it.

## Prerequisites

- A separate PC/server for MySQL (Windows, Linux, or macOS)
- Both PCs on the same local network
- Basic command line knowledge

## Step 1: Install MySQL Server

### For Windows:

1. Download MySQL Community Server from: https://dev.mysql.com/downloads/mysql/
2. Run the installer (mysql-installer-web-community-8.x.x.msi)
3. Choose "Server Only" or "Full" installation
4. Configure MySQL Server:
   - Choose "Development Computer" for server configuration
   - Set a root password (remember this!)
   - Create a new user: `electrical_assets_user` with password
5. Complete the installation

### For Ubuntu/Debian Linux:

\`\`\`bash
# Update package index
sudo apt update

# Install MySQL Server
sudo apt install mysql-server

# Secure MySQL installation
sudo mysql_secure_installation

# Log into MySQL
sudo mysql

# Create database and user
CREATE DATABASE electrical_assets CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'electrical_assets_user'@'%' IDENTIFIED BY 'your_secure_password';
GRANT ALL PRIVILEGES ON electrical_assets.* TO 'electrical_assets_user'@'%';
FLUSH PRIVILEGES;
EXIT;
\`\`\`

### For macOS:

\`\`\`bash
# Install using Homebrew
brew install mysql

# Start MySQL service
brew services start mysql

# Secure MySQL installation
mysql_secure_installation

# Log into MySQL
mysql -u root -p

# Create database and user
CREATE DATABASE electrical_assets CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'electrical_assets_user'@'%' IDENTIFIED BY 'your_secure_password';
GRANT ALL PRIVILEGES ON electrical_assets.* TO 'electrical_assets_user'@'%';
FLUSH PRIVILEGES;
EXIT;
\`\`\`

## Step 2: Configure MySQL for Network Access

### Find your MySQL server's IP address:

**Windows:**
\`\`\`cmd
ipconfig
\`\`\`
Look for "IPv4 Address" (e.g., 192.168.1.100)

**Linux/macOS:**
\`\`\`bash
ip addr show
# or
ifconfig
\`\`\`
Look for inet address (e.g., 192.168.1.100)

### Allow remote connections:

**Windows:**
1. Open MySQL Workbench or command line
2. Edit `my.ini` file (usually in `C:\ProgramData\MySQL\MySQL Server 8.x\`)
3. Find and change:
   \`\`\`
   bind-address = 0.0.0.0
   \`\`\`
4. Restart MySQL service from Services panel

**Linux:**
1. Edit MySQL configuration:
   \`\`\`bash
   sudo nano /etc/mysql/mysql.conf.d/mysqld.cnf
   \`\`\`
2. Find and change:
   \`\`\`
   bind-address = 0.0.0.0
   \`\`\`
3. Restart MySQL:
   \`\`\`bash
   sudo systemctl restart mysql
   \`\`\`

**macOS:**
1. Edit MySQL configuration:
   \`\`\`bash
   nano /usr/local/etc/my.cnf
   \`\`\`
2. Add or change:
   \`\`\`
   bind-address = 0.0.0.0
   \`\`\`
3. Restart MySQL:
   \`\`\`bash
   brew services restart mysql
   \`\`\`

## Step 3: Configure Firewall

### Windows Firewall:
1. Open Windows Defender Firewall
2. Click "Advanced settings"
3. Click "Inbound Rules" → "New Rule"
4. Choose "Port" → Next
5. Enter port 3306 → Allow the connection
6. Apply to all profiles

### Linux (UFW):
\`\`\`bash
sudo ufw allow 3306/tcp
sudo ufw reload
\`\`\`

### macOS:
\`\`\`bash
# Enable firewall if not already enabled
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --setglobalstate on

# Allow MySQL
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --add /usr/local/mysql/bin/mysqld
\`\`\`

## Step 4: Run Database Schema

1. Copy the `database/schema.sql` file to your MySQL server
2. Run the schema script:

\`\`\`bash
mysql -u root -p < database/schema.sql
\`\`\`

Or using MySQL Workbench:
1. Open MySQL Workbench
2. Connect to your server
3. File → Open SQL Script → Select `schema.sql`
4. Execute the script

3. (Optional) Run seed data:
\`\`\`bash
mysql -u root -p electrical_assets < database/seed.sql
\`\`\`

## Step 5: Configure Your Next.js Application

1. Create a `.env.local` file in your Next.js project root:

\`\`\`env
# MySQL Database Configuration
MYSQL_HOST=192.168.1.100  # Replace with your MySQL server IP
MYSQL_PORT=3306
MYSQL_USER=electrical_assets_user
MYSQL_PASSWORD=your_secure_password
MYSQL_DATABASE=electrical_assets

# JWT Secret (generate a random string)
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
\`\`\`

2. Generate a secure JWT secret:
\`\`\`bash
# On Linux/macOS
openssl rand -base64 32

# On Windows PowerShell
[Convert]::ToBase64String((1..32 | ForEach-Object { Get-Random -Minimum 0 -Maximum 256 }))
\`\`\`

## Step 6: Install Node.js Dependencies

Your application needs these packages for MySQL and authentication:

\`\`\`bash
npm install mysql2 bcryptjs jsonwebtoken
npm install -D @types/bcryptjs @types/jsonwebtoken
\`\`\`

These dependencies should already be in your `package.json`.

## Step 7: Test Database Connection

Create a test file to verify connectivity:

\`\`\`typescript
// test-db-connection.ts
import { testConnection } from './lib/db/mysql'

async function test() {
  const connected = await testConnection()
  console.log(connected ? 'Database connected!' : 'Connection failed!')
}

test()
\`\`\`

Run: `npx tsx test-db-connection.ts`

## Step 8: Start Your Application

\`\`\`bash
npm run dev
\`\`\`

Your application should now be running and connected to your MySQL database!

## Troubleshooting

### Connection Refused
- Check if MySQL service is running
- Verify firewall settings
- Ensure bind-address is set to 0.0.0.0

### Access Denied
- Verify username and password in .env.local
- Check MySQL user permissions
- Ensure user is allowed from '%' (any host)

### Can't Connect from Network
- Ping the MySQL server IP from your dev machine
- Check both firewalls (server and client)
- Verify both machines are on the same network

### Table/Database Not Found
- Ensure schema.sql was executed successfully
- Check database name matches in .env.local
- Verify user has privileges on the database

## Security Recommendations for Production

1. Use strong passwords for MySQL users
2. Change JWT_SECRET to a random secure value
3. Use specific IP addresses instead of '%' for MySQL user hosts
4. Enable SSL/TLS for MySQL connections
5. Keep MySQL and Node.js updated
6. Set up regular database backups
7. Use environment-specific credentials
8. Never commit .env files to version control

## Database Backup

### Create a backup:
\`\`\`bash
mysqldump -u root -p electrical_assets > backup_$(date +%Y%m%d).sql
\`\`\`

### Restore from backup:
\`\`\`bash
mysql -u root -p electrical_assets < backup_20240109.sql
\`\`\`

## Next Steps

1. Create your first user account via the signup page
2. Start adding products, warranties, invoices, and payments
3. Explore the dashboard to see your data
4. Set up automated backups
5. Configure production environment when ready to deploy
\`\`\`

\`\`\`json file="" isHidden
