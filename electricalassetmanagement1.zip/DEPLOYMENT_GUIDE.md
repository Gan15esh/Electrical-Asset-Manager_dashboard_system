# Deployment Guide

This guide will help you deploy your Electrical Asset Management application with a self-hosted Supabase backend.

## Prerequisites

Before deployment, ensure you have:

1. ✅ Self-hosted Supabase instance running on your separate PC (see `SETUP_INSTRUCTIONS.md`)
2. ✅ Database schema and RLS policies applied
3. ✅ Environment variables configured
4. ✅ Network connectivity between your app server and database server

## Environment Variables

Create a `.env.local` file in your project root with the following variables:

\`\`\`env
# Supabase Configuration (from your self-hosted instance)
NEXT_PUBLIC_SUPABASE_URL=http://your_database_server_ip:8000
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_from_supabase_env

# Development redirect URL (for email confirmations during dev)
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000
\`\`\`

### Getting Your Keys

From your Supabase `.env` file on the database server:
- `NEXT_PUBLIC_SUPABASE_URL` = `http://your_server_ip:8000` (API URL)
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` = The `ANON_KEY` value from your Supabase `.env`

## Local Development

1. **Install dependencies:**
   \`\`\`bash
   npm install
   \`\`\`

2. **Start the development server:**
   \`\`\`bash
   npm run dev
   \`\`\`

3. **Open your browser:**
   \`\`\`
   http://localhost:3000
   \`\`\`

4. **Create your first account:**
   - Navigate to `/signup`
   - Create an admin account
   - You'll be redirected to the dashboard

## Production Deployment

### Option 1: Deploy to Vercel (Recommended)

1. **Push your code to GitHub**

2. **Import to Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Click "Import Project"
   - Select your GitHub repository

3. **Configure Environment Variables:**
   - Add all variables from `.env.local`
   - Make sure your database server is accessible from the internet or via VPN

4. **Deploy:**
   - Click "Deploy"
   - Your app will be live at `your-app.vercel.app`

### Option 2: Self-Host with Node.js

1. **Build the application:**
   \`\`\`bash
   npm run build
   \`\`\`

2. **Start the production server:**
   \`\`\`bash
   npm start
   \`\`\`

3. **Use a process manager (PM2):**
   \`\`\`bash
   npm install -g pm2
   pm2 start npm --name "asset-manager" -- start
   pm2 save
   pm2 startup
   \`\`\`

### Option 3: Docker Deployment

1. **Create Dockerfile:**
   \`\`\`dockerfile
   FROM node:20-alpine
   WORKDIR /app
   COPY package*.json ./
   RUN npm ci --only=production
   COPY . .
   RUN npm run build
   EXPOSE 3000
   CMD ["npm", "start"]
   \`\`\`

2. **Build and run:**
   \`\`\`bash
   docker build -t asset-manager .
   docker run -p 3000:3000 --env-file .env.local asset-manager
   \`\`\`

## Network Configuration

### If Database Server is on Local Network:

1. **Open firewall ports on database server:**
   \`\`\`bash
   sudo ufw allow 8000/tcp  # Supabase API
   sudo ufw allow 5432/tcp  # PostgreSQL (optional, for direct access)
   \`\`\`

2. **Use local IP address:**
   \`\`\`env
   NEXT_PUBLIC_SUPABASE_URL=http://192.168.1.100:8000
   \`\`\`

### If Database Server is Remote:

1. **Set up reverse proxy (nginx/Caddy) with SSL:**
   \`\`\`nginx
   server {
       listen 443 ssl;
       server_name api.yourdomain.com;
       
       ssl_certificate /path/to/cert.pem;
       ssl_certificate_key /path/to/key.pem;
       
       location / {
           proxy_pass http://localhost:8000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
   }
   \`\`\`

2. **Use HTTPS URL:**
   \`\`\`env
   NEXT_PUBLIC_SUPABASE_URL=https://api.yourdomain.com
   \`\`\`

## Security Checklist

Before going to production:

- [ ] Change all default passwords in Supabase `.env`
- [ ] Use strong JWT secrets (minimum 32 characters)
- [ ] Enable HTTPS for production (use Let's Encrypt)
- [ ] Configure CORS properly in Supabase
- [ ] Set up regular database backups
- [ ] Enable firewall rules to restrict access
- [ ] Review Row Level Security (RLS) policies
- [ ] Disable email confirmation for development (or configure SMTP)
- [ ] Set up monitoring and logging
- [ ] Configure rate limiting

## Database Backups

### Automated Backups:

\`\`\`bash
# Create backup script
cat > /usr/local/bin/backup-supabase.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/backups/supabase"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR
docker exec supabase-db pg_dump -U postgres postgres > "$BACKUP_DIR/backup_$DATE.sql"
# Keep only last 7 days
find $BACKUP_DIR -name "backup_*.sql" -mtime +7 -delete
EOF

chmod +x /usr/local/bin/backup-supabase.sh

# Add to crontab (daily at 2 AM)
echo "0 2 * * * /usr/local/bin/backup-supabase.sh" | crontab -
\`\`\`

### Manual Backup:

\`\`\`bash
docker exec supabase-db pg_dump -U postgres postgres > backup_$(date +%Y%m%d).sql
\`\`\`

### Restore from Backup:

\`\`\`bash
docker exec -i supabase-db psql -U postgres postgres < backup_20240115.sql
\`\`\`

## Monitoring

### Check Application Health:

\`\`\`bash
# Check if Next.js is running
curl http://localhost:3000

# Check if Supabase API is accessible
curl http://your_db_server:8000/health
\`\`\`

### View Logs:

\`\`\`bash
# Next.js logs (if using PM2)
pm2 logs asset-manager

# Supabase logs
docker logs supabase-db
docker logs supabase-kong
\`\`\`

## Troubleshooting

### Connection Issues:

1. **Check database server is running:**
   \`\`\`bash
   docker ps | grep supabase
   \`\`\`

2. **Test network connectivity:**
   \`\`\`bash
   ping your_database_server_ip
   telnet your_database_server_ip 8000
   \`\`\`

3. **Verify environment variables:**
   - Check `.env.local` has correct values
   - Restart Next.js after changing env vars

### Authentication Issues:

1. **Check JWT secrets match** between Supabase and your app
2. **Verify ANON_KEY** is correct
3. **Check browser console** for CORS errors
4. **Clear browser cookies** and try again

### Database Issues:

1. **Check Row Level Security policies** are enabled
2. **Verify user has permissions** in Supabase
3. **Check database logs** for SQL errors
4. **Test with Supabase Studio** SQL editor

## Performance Optimization

1. **Enable caching:**
   - Use Next.js ISR for static pages
   - Cache API responses with SWR

2. **Database optimization:**
   - Ensure indexes are created (done in migration)
   - Monitor slow queries in Supabase logs
   - Use connection pooling (built into Supabase)

3. **CDN for assets:**
   - Use Vercel's CDN for images
   - Compress images before upload

## Updates and Maintenance

### Update Next.js Application:

\`\`\`bash
git pull origin main
npm install
npm run build
pm2 restart asset-manager
\`\`\`

### Update Supabase:

\`\`\`bash
cd supabase/docker
docker compose pull
docker compose up -d
\`\`\`

## Support and Resources

- **Next.js Docs:** https://nextjs.org/docs
- **Supabase Self-Hosting:** https://supabase.com/docs/guides/self-hosting
- **Docker Docs:** https://docs.docker.com

## Next Steps

After deployment:

1. Create your first admin account via signup page
2. Add products, warranties, invoices, and payments
3. Set up regular backups
4. Monitor application performance
5. Train your team on using the system

Your Electrical Asset Management system is now ready for production use!
