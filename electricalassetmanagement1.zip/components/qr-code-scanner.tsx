"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Camera, Upload, Scan, CheckCircle2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import jsQR from "jsqr"

interface QRCodeScannerProps {
  onScan: (data: string) => void
}

export function QRCodeScanner({ onScan }: QRCodeScannerProps) {
  const [scanMethod, setScanMethod] = useState<"camera" | "upload" | "manual">("manual")
  const [manualInput, setManualInput] = useState("")
  const [isScanning, setIsScanning] = useState(false)
  const [lastScanned, setLastScanned] = useState<string | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const animationRef = useRef<number | null>(null)
  const { toast } = useToast()

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }
    setIsScanning(false)
  }

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.play()
        setIsScanning(true)
        scanQRCode()
      }
    } catch (error) {
      console.error("[v0] Error accessing camera:", error)
      toast({
        title: "Camera Error",
        description: "Could not access camera. Please check permissions.",
        variant: "destructive",
      })
    }
  }

  const scanQRCode = () => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    if (!context) return

    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      context.drawImage(video, 0, 0, canvas.width, canvas.height)

      const imageData = context.getImageData(0, 0, canvas.width, canvas.height)
      const code = jsQR(imageData.data, imageData.width, imageData.height)

      if (code) {
        setLastScanned(code.data)
        onScan(code.data)
        toast({
          title: "QR Code Scanned!",
          description: `Data: ${code.data}`,
        })
        stopCamera()
        return
      }
    }

    animationRef.current = requestAnimationFrame(scanQRCode)
  }

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    try {
      const img = new Image()
      const reader = new FileReader()

      reader.onload = (e) => {
        img.onload = () => {
          const canvas = canvasRef.current
          if (!canvas) return

          const context = canvas.getContext("2d")
          if (!context) return

          canvas.width = img.width
          canvas.height = img.height
          context.drawImage(img, 0, 0)

          const imageData = context.getImageData(0, 0, canvas.width, canvas.height)
          const code = jsQR(imageData.data, imageData.width, imageData.height)

          if (code) {
            setLastScanned(code.data)
            onScan(code.data)
            toast({
              title: "QR Code Detected!",
              description: `Data: ${code.data}`,
            })
          } else {
            toast({
              title: "No QR Code Found",
              description: "Could not detect a QR code in the image",
              variant: "destructive",
            })
          }
        }
        img.src = e.target?.result as string
      }

      reader.readAsDataURL(file)
    } catch (error) {
      console.error("[v0] Error reading image:", error)
      toast({
        title: "Error",
        description: "Failed to read image file",
        variant: "destructive",
      })
    }
  }

  const handleManualSubmit = () => {
    if (manualInput.trim()) {
      setLastScanned(manualInput.trim())
      onScan(manualInput.trim())
      setManualInput("")
      toast({
        title: "Data Added",
        description: `Manual input: ${manualInput.trim()}`,
      })
    }
  }

  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [])

  return (
    <div className="space-y-4">
      <div className="flex space-x-2">
        <Button
          variant={scanMethod === "manual" ? "default" : "outline"}
          onClick={() => {
            stopCamera()
            setScanMethod("manual")
          }}
          className="flex-1"
        >
          <Scan className="w-4 h-4 mr-2" />
          Manual Entry
        </Button>
        <Button
          variant={scanMethod === "camera" ? "default" : "outline"}
          onClick={() => {
            setScanMethod("camera")
            startCamera()
          }}
          className="flex-1"
        >
          <Camera className="w-4 h-4 mr-2" />
          Camera
        </Button>
        <Button
          variant={scanMethod === "upload" ? "default" : "outline"}
          onClick={() => {
            stopCamera()
            setScanMethod("upload")
          }}
          className="flex-1"
        >
          <Upload className="w-4 h-4 mr-2" />
          Upload
        </Button>
      </div>

      {scanMethod === "manual" && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="manual-input">Enter Data Manually</Label>
                <div className="flex space-x-2">
                  <Input
                    id="manual-input"
                    placeholder="Enter SKU, barcode, or any data..."
                    value={manualInput}
                    onChange={(e) => setManualInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        handleManualSubmit()
                      }
                    }}
                  />
                  <Button onClick={handleManualSubmit} disabled={!manualInput.trim()}>
                    Add
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {scanMethod === "camera" && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
                <video ref={videoRef} className="w-full h-full object-cover" playsInline />
                <canvas ref={canvasRef} className="hidden" />
                {isScanning && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-64 h-64 border-4 border-emerald-500 rounded-lg animate-pulse" />
                  </div>
                )}
              </div>
              {isScanning && (
                <Button onClick={stopCamera} variant="destructive" className="w-full">
                  Stop Camera
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {scanMethod === "upload" && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="qr-upload">Upload QR Code Image</Label>
                <Input
                  id="qr-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="cursor-pointer"
                />
              </div>
              <canvas ref={canvasRef} className="hidden" />
            </div>
          </CardContent>
        </Card>
      )}

      {lastScanned && (
        <Card className="border-emerald-500 bg-emerald-50 dark:bg-emerald-950">
          <CardContent className="pt-6">
            <div className="flex items-start space-x-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5" />
              <div>
                <p className="font-semibold text-emerald-900 dark:text-emerald-100">Last Scanned Data</p>
                <p className="text-sm text-emerald-700 dark:text-emerald-300 break-all">{lastScanned}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
