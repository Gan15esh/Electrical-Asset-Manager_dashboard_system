"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"

interface LogoutButtonProps {
  variant?: "default" | "ghost" | "outline"
  className?: string
}

export function LogoutButton({ variant = "ghost", className }: LogoutButtonProps) {
  const router = useRouter()

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/signout", {
        method: "POST",
      })
      router.push("/login")
      router.refresh()
    } catch (error) {
      console.error("[v0] Logout error:", error)
    }
  }

  return (
    <Button variant={variant} onClick={handleLogout} className={className}>
      <LogOut className="w-4 h-4 mr-2" />
      Logout
    </Button>
  )
}
