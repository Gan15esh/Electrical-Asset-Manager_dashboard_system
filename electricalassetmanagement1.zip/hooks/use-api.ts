"use client"

import { useState, useEffect, useCallback } from "react"
import { apiClient } from "@/lib/api/client"

interface UseApiOptions<T> {
  initialData?: T
  autoFetch?: boolean
}

export function useApi<T>(apiMethod: () => Promise<T>, options: UseApiOptions<T> = {}) {
  const { initialData, autoFetch = true } = options
  const [data, setData] = useState<T | undefined>(initialData)
  const [isLoading, setIsLoading] = useState(autoFetch)
  const [error, setError] = useState<string | null>(null)

  const fetchData = useCallback(async () => {
    try {
      setIsLoading(true)
      setError(null)
      const result = await apiMethod()
      setData(result)
      return result
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An error occurred"
      setError(errorMessage)
      console.error("[v0] API error:", err)
      throw err
    } finally {
      setIsLoading(false)
    }
  }, [apiMethod])

  useEffect(() => {
    if (autoFetch) {
      fetchData()
    }
  }, [autoFetch, fetchData])

  const refetch = useCallback(() => {
    return fetchData()
  }, [fetchData])

  return { data, isLoading, error, refetch }
}

// Specific hooks for common use cases
export function useProducts(filters?: { category?: string; supplier?: string; status?: string }) {
  return useApi(() => apiClient.getProducts(filters))
}

export function useProductStats() {
  return useApi(() => apiClient.getProductStats())
}

export function useWarranties(filters?: { status?: string; supplier?: string }) {
  return useApi(() => apiClient.getWarranties(filters))
}

export function useWarrantyStats() {
  return useApi(() => apiClient.getWarrantyStats())
}

export function useInvoices(filters?: { status?: string; supplier?: string }) {
  return useApi(() => apiClient.getInvoices(filters))
}

export function useInvoiceStats() {
  return useApi(() => apiClient.getInvoiceStats())
}

export function usePayments(filters?: { status?: string; supplier?: string; invoice_id?: string }) {
  return useApi(() => apiClient.getPayments(filters))
}

export function usePaymentStats() {
  return useApi(() => apiClient.getPaymentStats())
}
