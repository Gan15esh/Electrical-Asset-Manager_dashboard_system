"use client"

import type React from "react"

import { useState, useRef } from "react"
import { NavHeader } from "@/components/nav-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Upload, Download, Plus, Trash2, QrCode, Sheet, Edit2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import * as XLSX from "xlsx"
import { QRCodeScanner } from "@/components/qr-code-scanner"

const PAGE_EMOJIS = ["📊", "📈", "📉", "📋", "📝", "📁", "📂", "🗂️", "📑", "🎯", "✅", "💾", "⚡", "🔥", "💼", "🚀"]

interface ExcelData {
  [key: string]: string | number
}

interface SheetData {
  name: string
  data: ExcelData[]
  columns: string[]
}

export default function ExcelManagerPage() {
  const [sheets, setSheets] = useState<SheetData[]>([])
  const [activeSheetIndex, setActiveSheetIndex] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const [editingCell, setEditingCell] = useState<{ row: number; col: string } | null>(null)
  const [editValue, setEditValue] = useState("")
  const [isScanDialogOpen, setIsScanDialogOpen] = useState(false)
  const [scanMode, setScanMode] = useState<"add" | "update">("add")
  const [selectedColumn, setSelectedColumn] = useState<string>("")
  const [isAddRowDialogOpen, setIsAddRowDialogOpen] = useState(false)
  const [newRowData, setNewRowData] = useState<ExcelData>({})
  const [selectedEmoji, setSelectedEmoji] = useState("📊")
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setIsUploading(true)
    try {
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data, { type: "array" })

      const loadedSheets: SheetData[] = workbook.SheetNames.map((sheetName) => {
        const worksheet = workbook.Sheets[sheetName]
        const jsonData = XLSX.utils.sheet_to_json<ExcelData>(worksheet)
        const columns = jsonData.length > 0 ? Object.keys(jsonData[0]) : []

        return {
          name: sheetName,
          data: jsonData,
          columns,
        }
      })

      setSheets(loadedSheets)
      setActiveSheetIndex(0)
      toast({
        title: "Success!",
        description: `Loaded ${loadedSheets.length} sheet(s) with ${loadedSheets[0]?.data.length || 0} rows`,
      })
    } catch (error) {
      console.error("[v0] Error loading Excel file:", error)
      toast({
        title: "Error",
        description: "Failed to load Excel file. Please check the file format.",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  const handleDownload = () => {
    if (sheets.length === 0) {
      toast({
        title: "No data",
        description: "Please upload an Excel file first",
        variant: "destructive",
      })
      return
    }

    const workbook = XLSX.utils.book_new()

    sheets.forEach((sheet) => {
      const worksheet = XLSX.utils.json_to_sheet(sheet.data)
      XLSX.utils.book_append_sheet(workbook, worksheet, sheet.name)
    })

    XLSX.writeFile(workbook, `asset-data-${Date.now()}.xlsx`)
    toast({
      title: "Downloaded!",
      description: "Excel file has been saved successfully",
    })
  }

  const handleCellEdit = (rowIndex: number, column: string, value: string | number) => {
    const updatedSheets = [...sheets]
    updatedSheets[activeSheetIndex].data[rowIndex][column] = value
    setSheets(updatedSheets)
    setEditingCell(null)
    setEditValue("")
  }

  const handleDeleteRow = (rowIndex: number) => {
    const updatedSheets = [...sheets]
    updatedSheets[activeSheetIndex].data.splice(rowIndex, 1)
    setSheets(updatedSheets)
    toast({
      title: "Row deleted",
      description: "The row has been removed successfully",
    })
  }

  const handleAddRow = () => {
    if (sheets.length === 0) {
      toast({
        title: "No sheet available",
        description: "Please upload an Excel file first",
        variant: "destructive",
      })
      return
    }

    const updatedSheets = [...sheets]
    updatedSheets[activeSheetIndex].data.push(newRowData)
    setSheets(updatedSheets)
    setNewRowData({})
    setIsAddRowDialogOpen(false)
    toast({
      title: "Row added",
      description: "New row has been added successfully",
    })
  }

  const handleQRScan = (data: string) => {
    if (sheets.length === 0) {
      toast({
        title: "No sheet available",
        description: "Please upload an Excel file first",
        variant: "destructive",
      })
      return
    }

    if (!selectedColumn) {
      toast({
        title: "Select a column",
        description: "Please select which column to populate with QR data",
        variant: "destructive",
      })
      return
    }

    if (scanMode === "add") {
      const newRow: ExcelData = { [selectedColumn]: data }
      const updatedSheets = [...sheets]
      updatedSheets[activeSheetIndex].data.push(newRow)
      setSheets(updatedSheets)
      toast({
        title: "QR data added",
        description: `Added "${data}" to ${selectedColumn}`,
      })
    } else {
      toast({
        title: "QR scanned",
        description: `Scanned: ${data}`,
      })
    }
  }

  const activeSheet = sheets[activeSheetIndex]

  return (
    <div className="min-h-screen gradient-page">
      <NavHeader />
      <main className="container py-8">
        <div className="mb-8 p-6 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="text-5xl hover:scale-110 transition-transform cursor-pointer bg-white/20 backdrop-blur-sm rounded-2xl p-3"
              >
                {selectedEmoji}
              </button>
              <div>
                <h1 className="text-4xl font-bold mb-2">Excel Manager</h1>
                <p className="text-emerald-100">Upload, edit, and manage Excel data with QR code integration</p>
              </div>
            </div>
            <div className="flex space-x-3">
              <Button
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="bg-white hover:bg-white/90 text-emerald-600 font-semibold shadow-lg"
              >
                <Upload className="w-4 h-4 mr-2" />
                {isUploading ? "Uploading..." : "Upload Excel"}
              </Button>
              <Button
                onClick={handleDownload}
                disabled={sheets.length === 0}
                className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border-white/30 text-white"
              >
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>
          </div>

          {showEmojiPicker && (
            <div className="mt-4 p-4 bg-white/10 backdrop-blur-md rounded-xl border border-white/20">
              <p className="text-sm text-emerald-100 mb-3 font-medium">Choose your page icon:</p>
              <div className="grid grid-cols-8 gap-3">
                {PAGE_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => {
                      setSelectedEmoji(emoji)
                      setShowEmojiPicker(false)
                    }}
                    className="text-3xl hover:scale-125 transition-transform bg-white/20 hover:bg-white/30 rounded-lg p-2"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <input ref={fileInputRef} type="file" accept=".xlsx,.xls" onChange={handleFileUpload} className="hidden" />

        {sheets.length === 0 ? (
          <Card className="border-2 border-dashed border-muted-foreground/25 bg-muted/10">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <Sheet className="w-16 h-16 text-muted-foreground/50 mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Excel file loaded</h3>
              <p className="text-muted-foreground mb-6 text-center max-w-md">
                Upload an Excel file (.xls or .xlsx) to start editing and managing your data
              </p>
              <Button onClick={() => fileInputRef.current?.click()} size="lg">
                <Upload className="w-4 h-4 mr-2" />
                Upload Excel File
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {sheets.map((sheet, index) => (
                  <Button
                    key={index}
                    variant={index === activeSheetIndex ? "default" : "outline"}
                    onClick={() => setActiveSheetIndex(index)}
                    className={index === activeSheetIndex ? "bg-gradient-to-r from-emerald-600 to-teal-600" : ""}
                  >
                    <Sheet className="w-4 h-4 mr-2" />
                    {sheet.name}
                  </Button>
                ))}
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setNewRowData({})
                    setIsAddRowDialogOpen(true)
                  }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Row
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setIsScanDialogOpen(true)}
                  className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white border-0 hover:from-blue-600 hover:to-indigo-700"
                >
                  <QrCode className="w-4 h-4 mr-2" />
                  Scan QR Code
                </Button>
              </div>
            </div>

            <Card className="border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{activeSheet.name}</span>
                  <span className="text-sm font-normal text-muted-foreground">
                    {activeSheet.data.length} rows × {activeSheet.columns.length} columns
                  </span>
                </CardTitle>
                <CardDescription>Edit cells by clicking on them</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">#</TableHead>
                        {activeSheet.columns.map((column) => (
                          <TableHead key={column} className="font-bold">
                            {column}
                          </TableHead>
                        ))}
                        <TableHead className="w-24 text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {activeSheet.data.map((row, rowIndex) => (
                        <TableRow key={rowIndex} className="hover:bg-muted/50">
                          <TableCell className="font-medium text-muted-foreground">{rowIndex + 1}</TableCell>
                          {activeSheet.columns.map((column) => (
                            <TableCell
                              key={`${rowIndex}-${column}`}
                              className="cursor-pointer hover:bg-accent/50 transition-colors"
                              onClick={() => {
                                setEditingCell({ row: rowIndex, col: column })
                                setEditValue(String(row[column] || ""))
                              }}
                            >
                              {editingCell?.row === rowIndex && editingCell?.col === column ? (
                                <Input
                                  value={editValue}
                                  onChange={(e) => setEditValue(e.target.value)}
                                  onBlur={() => handleCellEdit(rowIndex, column, editValue)}
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") {
                                      handleCellEdit(rowIndex, column, editValue)
                                    } else if (e.key === "Escape") {
                                      setEditingCell(null)
                                      setEditValue("")
                                    }
                                  }}
                                  autoFocus
                                  className="h-8"
                                />
                              ) : (
                                <div className="flex items-center space-x-2">
                                  <span>{row[column]}</span>
                                  <Edit2 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                                </div>
                              )}
                            </TableCell>
                          ))}
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteRow(rowIndex)}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <Dialog open={isScanDialogOpen} onOpenChange={setIsScanDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Scan QR Code</DialogTitle>
              <DialogDescription>Scan QR codes to automatically populate data into your Excel sheet</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Scan Mode</Label>
                  <Select value={scanMode} onValueChange={(value: "add" | "update") => setScanMode(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="add">Add New Row</SelectItem>
                      <SelectItem value="update">Update Existing Row</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Target Column</Label>
                  <Select value={selectedColumn} onValueChange={setSelectedColumn}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select column" />
                    </SelectTrigger>
                    <SelectContent>
                      {activeSheet?.columns.map((column) => (
                        <SelectItem key={column} value={column}>
                          {column}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <QRCodeScanner onScan={handleQRScan} />
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={isAddRowDialogOpen} onOpenChange={setIsAddRowDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Row</DialogTitle>
              <DialogDescription>Enter data for the new row</DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4 py-4">
              {activeSheet?.columns.map((column) => (
                <div key={column} className="space-y-2">
                  <Label htmlFor={column}>{column}</Label>
                  <Input
                    id={column}
                    value={newRowData[column] || ""}
                    onChange={(e) => setNewRowData({ ...newRowData, [column]: e.target.value })}
                    placeholder={`Enter ${column}`}
                  />
                </div>
              ))}
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsAddRowDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddRow}>
                <Plus className="w-4 h-4 mr-2" />
                Add Row
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
