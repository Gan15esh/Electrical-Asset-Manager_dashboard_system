"use client"

import { useState } from "react"
import { NavHeader } from "@/components/nav-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, Eye, Download, FileText, DollarSign, Clock, CheckCircle } from "lucide-react"

interface Invoice {
  id: string
  invoiceNumber: string
  supplier: string
  date: string
  dueDate: string
  amount: number
  status: "Paid" | "Pending" | "Overdue"
  items: string[]
  paymentMethod?: string
}

const mockInvoices: Invoice[] = [
  {
    id: "1",
    invoiceNumber: "INV-2024-0453",
    supplier: "ABB Ltd.",
    date: "2024-03-01",
    dueDate: "2024-03-31",
    amount: 12500.0,
    status: "Paid",
    items: ["Circuit Breaker MCB-450 (x10)", "Junction Box JB-200 (x5)"],
    paymentMethod: "Bank Transfer",
  },
  {
    id: "2",
    invoiceNumber: "INV-2024-0454",
    supplier: "Siemens",
    date: "2024-03-05",
    dueDate: "2024-04-05",
    amount: 28750.5,
    status: "Pending",
    items: ["Transformer TR-8820 (x2)"],
  },
  {
    id: "3",
    invoiceNumber: "INV-2024-0455",
    supplier: "Havells",
    date: "2024-02-20",
    dueDate: "2024-03-20",
    amount: 8920.0,
    status: "Overdue",
    items: ["Cable Wire CW-2200 (x100m)"],
  },
  {
    id: "4",
    invoiceNumber: "INV-2024-0456",
    supplier: "Schneider Electric",
    date: "2024-03-10",
    dueDate: "2024-04-10",
    amount: 15600.0,
    status: "Pending",
    items: ["Panel Board PB-1150 (x4)", "Distribution Unit DU-320 (x2)"],
  },
  {
    id: "5",
    invoiceNumber: "INV-2024-0457",
    supplier: "Legrand",
    date: "2024-03-08",
    dueDate: "2024-04-08",
    amount: 6250.0,
    status: "Paid",
    items: ["Junction Box JB-200 (x20)", "Cable Gland CG-150 (x50)"],
    paymentMethod: "Credit Card",
  },
]

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState<Invoice[]>(mockInvoices)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [isStatsDialogOpen, setIsStatsDialogOpen] = useState(false)
  const [newInvoice, setNewInvoice] = useState<Partial<Invoice>>({
    status: "Pending",
  })

  const filteredInvoices = invoices.filter((invoice) => {
    const matchesSearch =
      invoice.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.supplier.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const handleAddInvoice = () => {
    if (newInvoice.invoiceNumber && newInvoice.supplier && newInvoice.amount) {
      const invoice: Invoice = {
        id: (invoices.length + 1).toString(),
        invoiceNumber: newInvoice.invoiceNumber,
        supplier: newInvoice.supplier,
        date: newInvoice.date || new Date().toISOString().split("T")[0],
        dueDate: newInvoice.dueDate || new Date().toISOString().split("T")[0],
        amount: newInvoice.amount,
        status: newInvoice.status || "Pending",
        items: [],
      }
      setInvoices([...invoices, invoice])
      setIsAddDialogOpen(false)
      setNewInvoice({ status: "Pending" })
    }
  }

  const handleViewInvoice = (invoice: Invoice) => {
    setSelectedInvoice(invoice)
    setIsViewDialogOpen(true)
  }

  const handleViewCategory = (category: string) => {
    setSelectedCategory(category)
    setIsStatsDialogOpen(true)
  }

  const getCategoryInvoices = () => {
    switch (selectedCategory) {
      case "all":
        return invoices
      case "paid":
        return invoices.filter((inv) => inv.status === "Paid")
      case "pending":
        return invoices.filter((inv) => inv.status === "Pending")
      case "overdue":
        return invoices.filter((inv) => inv.status === "Overdue")
      default:
        return invoices
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Paid":
        return "bg-green-500"
      case "Pending":
        return "bg-yellow-500"
      case "Overdue":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const totalAmount = filteredInvoices.reduce((sum, inv) => sum + inv.amount, 0)
  const paidAmount = filteredInvoices.filter((inv) => inv.status === "Paid").reduce((sum, inv) => sum + inv.amount, 0)
  const pendingAmount = filteredInvoices
    .filter((inv) => inv.status === "Pending")
    .reduce((sum, inv) => sum + inv.amount, 0)
  const overdueAmount = filteredInvoices
    .filter((inv) => inv.status === "Overdue")
    .reduce((sum, inv) => sum + inv.amount, 0)

  return (
    <div className="min-h-screen bg-background">
      <NavHeader />
      <main className="container py-8">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Invoice Management</h1>
            <p className="text-muted-foreground">Track and manage supplier invoices and payments</p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                Add Invoice
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Invoice</DialogTitle>
                <DialogDescription>Enter invoice details for tracking</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="invoiceNumber">Invoice Number *</Label>
                  <Input
                    id="invoiceNumber"
                    placeholder="INV-2024-0001"
                    value={newInvoice.invoiceNumber || ""}
                    onChange={(e) => setNewInvoice({ ...newInvoice, invoiceNumber: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="supplier">Supplier *</Label>
                  <Input
                    id="supplier"
                    placeholder="ABB Ltd."
                    value={newInvoice.supplier || ""}
                    onChange={(e) => setNewInvoice({ ...newInvoice, supplier: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Invoice Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={newInvoice.date || ""}
                      onChange={(e) => setNewInvoice({ ...newInvoice, date: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dueDate">Due Date</Label>
                    <Input
                      id="dueDate"
                      type="date"
                      value={newInvoice.dueDate || ""}
                      onChange={(e) => setNewInvoice({ ...newInvoice, dueDate: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount *</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={newInvoice.amount || ""}
                    onChange={(e) => setNewInvoice({ ...newInvoice, amount: Number.parseFloat(e.target.value) })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={newInvoice.status}
                    onValueChange={(value) => setNewInvoice({ ...newInvoice, status: value as Invoice["status"] })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pending">Pending</SelectItem>
                      <SelectItem value="Paid">Paid</SelectItem>
                      <SelectItem value="Overdue">Overdue</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddInvoice}>Add Invoice</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => handleViewCategory("all")}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Amount</CardTitle>
              <DollarSign className="w-5 h-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{totalAmount.toLocaleString()}</div>
              <p className="text-xs text-primary mt-1">Click to view all</p>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => handleViewCategory("paid")}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Paid</CardTitle>
              <CheckCircle className="w-5 h-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">₹{paidAmount.toLocaleString()}</div>
              <p className="text-xs text-primary mt-1">Click to view all</p>
            </CardContent>
          </Card>
          <Card
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => handleViewCategory("pending")}
          >
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <Clock className="w-5 h-5 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">₹{pendingAmount.toLocaleString()}</div>
              <p className="text-xs text-primary mt-1">Click to view all</p>
            </CardContent>
          </Card>
          <Card
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => handleViewCategory("overdue")}
          >
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Overdue</CardTitle>
              <FileText className="w-5 h-5 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">₹{overdueAmount.toLocaleString()}</div>
              <p className="text-xs text-primary mt-1">Click to view all</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filter */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="Search by invoice number or supplier..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Paid">Paid</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Invoices Table */}
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice #</TableHead>
                  <TableHead>Supplier</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell className="font-medium">{invoice.invoiceNumber}</TableCell>
                    <TableCell>{invoice.supplier}</TableCell>
                    <TableCell>{invoice.date}</TableCell>
                    <TableCell>{invoice.dueDate}</TableCell>
                    <TableCell className="font-semibold">₹{invoice.amount.toLocaleString()}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(invoice.status)}`} />
                        <Badge
                          variant={
                            invoice.status === "Paid"
                              ? "default"
                              : invoice.status === "Overdue"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {invoice.status}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="ghost" size="icon" onClick={() => handleViewInvoice(invoice)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* View Invoice Dialog */}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Invoice Details</DialogTitle>
              <DialogDescription>{selectedInvoice?.invoiceNumber}</DialogDescription>
            </DialogHeader>
            {selectedInvoice && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Supplier</Label>
                    <p className="font-medium mt-1">{selectedInvoice.supplier}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Status</Label>
                    <div className="mt-1">
                      <Badge
                        variant={
                          selectedInvoice.status === "Paid"
                            ? "default"
                            : selectedInvoice.status === "Overdue"
                              ? "destructive"
                              : "secondary"
                        }
                      >
                        {selectedInvoice.status}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Invoice Date</Label>
                    <p className="font-medium mt-1">{selectedInvoice.date}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Due Date</Label>
                    <p className="font-medium mt-1">{selectedInvoice.dueDate}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Amount</Label>
                    <p className="text-2xl font-bold mt-1">₹{selectedInvoice.amount.toLocaleString()}</p>
                  </div>
                  {selectedInvoice.paymentMethod && (
                    <div>
                      <Label className="text-muted-foreground">Payment Method</Label>
                      <p className="font-medium mt-1">{selectedInvoice.paymentMethod}</p>
                    </div>
                  )}
                </div>

                {selectedInvoice.items.length > 0 && (
                  <div>
                    <Label className="text-muted-foreground">Items</Label>
                    <ul className="mt-2 space-y-2">
                      {selectedInvoice.items.map((item, index) => (
                        <li key={index} className="flex items-center space-x-2 text-sm">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="flex space-x-2 pt-4 border-t border-border">
                  <Button className="flex-1">
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                  </Button>
                  {selectedInvoice.status !== "Paid" && (
                    <Button className="flex-1 bg-transparent" variant="outline">
                      Mark as Paid
                    </Button>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Category Invoices Dialog */}
        <Dialog open={isStatsDialogOpen} onOpenChange={setIsStatsDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {selectedCategory === "all" && "All Invoices"}
                {selectedCategory === "paid" && "Paid Invoices"}
                {selectedCategory === "pending" && "Pending Invoices"}
                {selectedCategory === "overdue" && "Overdue Invoices"}
              </DialogTitle>
              <DialogDescription>{getCategoryInvoices().length} invoice(s) in this category</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {getCategoryInvoices().map((invoice) => (
                <Card key={invoice.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-lg">{invoice.invoiceNumber}</h3>
                          <Badge
                            variant={
                              invoice.status === "Paid"
                                ? "default"
                                : invoice.status === "Overdue"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {invoice.status}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Supplier</p>
                            <p className="font-medium">{invoice.supplier}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Amount</p>
                            <p className="text-xl font-bold">₹{invoice.amount.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Invoice Date</p>
                            <p className="font-medium">{invoice.date}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Due Date</p>
                            <p className="font-medium">{invoice.dueDate}</p>
                          </div>
                          {invoice.paymentMethod && (
                            <div>
                              <p className="text-muted-foreground">Payment Method</p>
                              <p className="font-medium">{invoice.paymentMethod}</p>
                            </div>
                          )}
                        </div>
                        {invoice.items.length > 0 && (
                          <div className="mt-3">
                            <p className="text-muted-foreground text-xs mb-1">Items</p>
                            <ul className="space-y-1">
                              {invoice.items.map((item, index) => (
                                <li key={index} className="flex items-center space-x-2 text-sm">
                                  <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                                  <span>{item}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex space-x-2 pt-4 border-t border-border">
                      <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
