"use client"

import { useState, useEffect } from "react"
import { NavHeader } from "@/components/nav-header"
import { Card, CardContent, CardDescription, CardTitle } from "@/components/ui/card"
import { Package, FileText, Shield, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { apiClient } from "@/lib/api/client"
import { Skeleton } from "@/components/ui/skeleton"

const PAGE_EMOJIS = ["⚡", "🔧", "⚙️", "🔌", "💡", "🏭", "📊", "🎯", "🚀", "💼", "📈", "🛠️", "⚠️", "✅", "📦", "🔋"]

export default function DashboardPage() {
  const [selectedEmoji, setSelectedEmoji] = useState("⚡")
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  const [stats, setStats] = useState({
    totalProducts: 0,
    activeWarranties: 0,
    pendingInvoices: 0,
    expiringSoon: 0,
  })
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchDashboardData() {
      try {
        setIsLoading(true)
        setError(null)

        const [productStats, warrantyStats, invoiceStats] = await Promise.all([
          apiClient.getProductStats(),
          apiClient.getWarrantyStats(),
          apiClient.getInvoiceStats(),
        ])

        setStats({
          totalProducts: productStats.totalProducts || 0,
          activeWarranties: warrantyStats.activeWarranties || 0,
          pendingInvoices: invoiceStats.pendingInvoices || 0,
          expiringSoon: warrantyStats.expiringSoon || 0,
        })
      } catch (err) {
        console.error("[v0] Error fetching dashboard data:", err)
        setError(err instanceof Error ? err.message : "Failed to load dashboard data")
      } finally {
        setIsLoading(false)
      }
    }

    fetchDashboardData()
  }, [])

  const statsData = [
    {
      title: "Total Products",
      value: stats.totalProducts.toLocaleString(),
      change: "+12.5%",
      trend: "up" as const,
      icon: Package,
      description: "Active electrical assets",
    },
    {
      title: "Active Warranties",
      value: stats.activeWarranties.toLocaleString(),
      change: "+5.2%",
      trend: "up" as const,
      icon: Shield,
      description: "Under warranty protection",
    },
    {
      title: "Pending Invoices",
      value: stats.pendingInvoices.toLocaleString(),
      change: "-8.1%",
      trend: "down" as const,
      icon: FileText,
      description: "Awaiting processing",
    },
    {
      title: "Expiring Soon",
      value: stats.expiringSoon.toLocaleString(),
      change: "+3.4%",
      trend: "up" as const,
      icon: AlertTriangle,
      description: "Warranties expiring in 30 days",
    },
  ]

  const recentActivity = [
    {
      id: 1,
      type: "product",
      title: "Circuit Breaker MCB-450",
      action: "Added to inventory",
      time: "2 hours ago",
      status: "success",
    },
    {
      id: 2,
      type: "warranty",
      title: "Transformer TR-8820",
      action: "Warranty expires in 15 days",
      time: "5 hours ago",
      status: "warning",
    },
    {
      id: 3,
      type: "invoice",
      title: "Invoice #INV-2024-0453",
      action: "Payment received",
      time: "1 day ago",
      status: "success",
    },
    {
      id: 4,
      type: "product",
      title: "Cable Wire CW-2200",
      action: "QR code generated",
      time: "1 day ago",
      status: "info",
    },
    {
      id: 5,
      type: "warranty",
      title: "Panel Board PB-1150",
      action: "Warranty registered",
      time: "2 days ago",
      status: "success",
    },
  ]

  const lowStockItems = [
    { name: "Miniature Circuit Breaker", sku: "MCB-320", stock: 5, threshold: 20 },
    { name: "Distribution Panel", sku: "DP-840", stock: 3, threshold: 10 },
    { name: "Cable Gland", sku: "CG-150", stock: 12, threshold: 50 },
    { name: "Junction Box", sku: "JB-200", stock: 8, threshold: 25 },
  ]

  return (
    <div className="min-h-screen gradient-page">
      <NavHeader />
      <main className="container py-8">
        <div className="mb-8 p-6 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="text-5xl hover:scale-110 transition-transform cursor-pointer bg-white/20 backdrop-blur-sm rounded-2xl p-3"
              >
                {selectedEmoji}
              </button>
              <div>
                <h1 className="text-4xl font-bold mb-2">Dashboard Overview</h1>
                <p className="text-blue-100">Monitor and manage your electrical asset ecosystem</p>
              </div>
            </div>
          </div>
          {showEmojiPicker && (
            <div className="mt-4 p-4 bg-white/10 backdrop-blur-md rounded-xl border border-white/20">
              <p className="text-sm text-blue-100 mb-3 font-medium">Choose your dashboard icon:</p>
              <div className="grid grid-cols-8 gap-3">
                {PAGE_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => {
                      setSelectedEmoji(emoji)
                      setShowEmojiPicker(false)
                    }}
                    className="text-3xl hover:scale-125 transition-transform bg-white/20 hover:bg-white/30 rounded-lg p-2"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-800">
            <p className="font-medium">Error loading dashboard data</p>
            <p className="text-sm">{error}</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statsData.map((stat, index) => {
            const Icon = stat.icon
            const TrendIcon = stat.trend === "up" ? TrendingUp : TrendingDown
            const gradients = [
              "bg-gradient-to-br from-blue-500 to-blue-600",
              "bg-gradient-to-br from-green-500 to-emerald-600",
              "bg-gradient-to-br from-amber-500 to-orange-600",
              "bg-gradient-to-br from-red-500 to-rose-600",
            ]
            return (
              <Card
                key={stat.title}
                className="border-0 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1 overflow-hidden"
              >
                <div className={`${gradients[index]} p-4 text-white`}>
                  {isLoading ? (
                    <>
                      <div className="flex items-center justify-between mb-3">
                        <Skeleton className="w-12 h-12 rounded-xl bg-white/20" />
                        <Skeleton className="w-16 h-6 rounded-full bg-white/20" />
                      </div>
                      <Skeleton className="h-4 w-24 mb-2 bg-white/20" />
                      <Skeleton className="h-8 w-20 mb-2 bg-white/20" />
                      <Skeleton className="h-3 w-32 bg-white/20" />
                    </>
                  ) : (
                    <>
                      <div className="flex items-center justify-between mb-3">
                        <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                          <Icon className="w-6 h-6" />
                        </div>
                        <span
                          className={`flex items-center text-sm font-medium px-2 py-1 rounded-full ${
                            stat.trend === "up" ? "bg-white/20" : "bg-black/20"
                          }`}
                        >
                          <TrendIcon className="w-3 h-3 mr-1" />
                          {stat.change}
                        </span>
                      </div>
                      <div className="text-sm font-medium opacity-90 mb-1">{stat.title}</div>
                      <div className="text-3xl font-bold mb-1">{stat.value}</div>
                      <div className="text-xs opacity-75">{stat.description}</div>
                    </>
                  )}
                </div>
              </Card>
            )
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 border-0 shadow-lg overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-500 to-purple-600 p-6 text-white">
              <CardTitle className="text-xl font-bold">Recent Activity</CardTitle>
              <CardDescription className="text-indigo-100">
                Latest updates across your asset management system
              </CardDescription>
            </div>
            <CardContent className="p-6">
              <div className="space-y-3">
                {recentActivity.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-start space-x-4 p-4 rounded-xl bg-gradient-to-r from-muted/50 to-muted/30 hover:from-muted to-muted/50 transition-all border border-border/50"
                  >
                    <div
                      className={`w-3 h-3 rounded-full mt-2 shadow-lg ${
                        activity.status === "success"
                          ? "bg-green-500 shadow-green-500/50"
                          : activity.status === "warning"
                            ? "bg-yellow-500 shadow-yellow-500/50"
                            : "bg-blue-500 shadow-blue-500/50"
                      }`}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-foreground text-sm">{activity.title}</p>
                      <p className="text-sm text-muted-foreground">{activity.action}</p>
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap bg-muted/50 px-2 py-1 rounded-full">
                      {activity.time}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg overflow-hidden">
            <div className="bg-gradient-to-br from-amber-500 to-orange-600 p-6 text-white">
              <div className="flex items-center space-x-2 mb-2">
                <AlertTriangle className="w-6 h-6" />
                <CardTitle className="text-xl font-bold">Low Stock Alert</CardTitle>
              </div>
              <CardDescription className="text-amber-100">Items below reorder threshold</CardDescription>
            </div>
            <CardContent className="p-6">
              <div className="space-y-4">
                {lowStockItems.map((item) => (
                  <div key={item.sku} className="space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm text-foreground truncate">{item.name}</p>
                        <p className="text-xs text-muted-foreground">SKU: {item.sku}</p>
                      </div>
                      <Badge
                        variant={item.stock < 10 ? "destructive" : "secondary"}
                        className={`ml-2 ${item.stock < 10 ? "bg-gradient-to-r from-red-500 to-rose-600 border-0" : "bg-gradient-to-r from-amber-500 to-orange-500 border-0 text-white"}`}
                      >
                        {item.stock} left
                      </Badge>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2.5 overflow-hidden">
                      <div
                        className={`h-2.5 rounded-full transition-all ${item.stock < 10 ? "bg-gradient-to-r from-red-500 to-rose-600" : "bg-gradient-to-r from-amber-500 to-orange-500"}`}
                        style={{ width: `${(item.stock / item.threshold) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
