"use client"

import { useState } from "react"
import { NavHeader } from "@/components/nav-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, Edit, Trash2, Package, AlertCircle, QrCode, Camera, Upload } from "lucide-react"

interface Product {
  id: string
  name: string
  sku: string
  category: string
  quantity: number
  location: string
  supplier: string
  purchaseDate: string
  condition: "Excellent" | "Good" | "Fair" | "Poor"
  status: "Active" | "Inactive" | "Maintenance"
  qrCodeUrl?: string
}

const mockProducts: Product[] = [
  {
    id: "1",
    name: "Circuit Breaker MCB-450",
    sku: "MCB-450",
    category: "Circuit Protection",
    quantity: 24,
    location: "Warehouse A - Shelf 12",
    supplier: "ABB Ltd.",
    purchaseDate: "2024-01-15",
    condition: "Excellent",
    status: "Active",
    qrCodeUrl: "/qr-code-mcb-450.jpg",
  },
  {
    id: "2",
    name: "Transformer TR-8820",
    sku: "TR-8820",
    category: "Power Distribution",
    quantity: 5,
    location: "Warehouse B - Bay 3",
    supplier: "Siemens",
    purchaseDate: "2023-11-20",
    condition: "Good",
    status: "Active",
    qrCodeUrl: "/qr-code-tr-8820.jpg",
  },
  {
    id: "3",
    name: "Cable Wire CW-2200",
    sku: "CW-2200",
    category: "Wiring",
    quantity: 150,
    location: "Warehouse A - Shelf 5",
    supplier: "Havells",
    purchaseDate: "2024-02-10",
    condition: "Excellent",
    status: "Active",
    qrCodeUrl: "/qr-code-cw-2200.jpg",
  },
  {
    id: "4",
    name: "Panel Board PB-1150",
    sku: "PB-1150",
    category: "Distribution Boards",
    quantity: 8,
    location: "Warehouse C - Section 2",
    supplier: "Schneider Electric",
    purchaseDate: "2023-12-05",
    condition: "Good",
    status: "Active",
    qrCodeUrl: "/qr-code-pb-1150.jpg",
  },
  {
    id: "5",
    name: "Junction Box JB-200",
    sku: "JB-200",
    category: "Enclosures",
    quantity: 45,
    location: "Warehouse A - Shelf 8",
    supplier: "Legrand",
    purchaseDate: "2024-01-25",
    condition: "Excellent",
    status: "Active",
  },
]

const PAGE_EMOJIS = ["📦", "📊", "🏭", "⚙️", "🔧", "🔌", "💡", "⚡", "🛠️", "📈", "🎯", "✅", "🚀", "💼", "🔋", "⚠️"]

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>(mockProducts)
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [isStatsDialogOpen, setIsStatsDialogOpen] = useState(false)
  const [isScanDialogOpen, setIsScanDialogOpen] = useState(false)
  const [scannedProduct, setScannedProduct] = useState<Product | null>(null)
  const [isProductDetailOpen, setIsProductDetailOpen] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [scanInput, setScanInput] = useState("")
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    condition: "Excellent",
    status: "Active",
  })
  const [selectedEmoji, setSelectedEmoji] = useState("📦")
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleAddProduct = () => {
    if (newProduct.name && newProduct.sku) {
      const product: Product = {
        id: (products.length + 1).toString(),
        name: newProduct.name,
        sku: newProduct.sku,
        category: newProduct.category || "",
        quantity: newProduct.quantity || 0,
        location: newProduct.location || "",
        supplier: newProduct.supplier || "",
        purchaseDate: newProduct.purchaseDate || new Date().toISOString().split("T")[0],
        condition: newProduct.condition || "Excellent",
        status: newProduct.status || "Active",
      }
      setProducts([...products, product])
      setIsAddDialogOpen(false)
      setNewProduct({ condition: "Excellent", status: "Active" })
    }
  }

  const handleDeleteProduct = (id: string) => {
    setProducts(products.filter((p) => p.id !== id))
  }

  const handleScanQR = () => {
    const product = products.find((p) => p.sku.toLowerCase() === scanInput.toLowerCase())
    if (product) {
      setScannedProduct(product)
      setScanInput("")
    } else {
      alert("Product not found! Please check the SKU.")
    }
  }

  const handleViewProduct = (product: Product) => {
    setSelectedProduct(product)
    setIsProductDetailOpen(true)
  }

  const handleViewCategory = (category: string) => {
    setSelectedCategory(category)
    setIsStatsDialogOpen(true)
  }

  const getCategoryProducts = () => {
    switch (selectedCategory) {
      case "total":
        return products
      case "active":
        return products.filter((p) => p.status === "Active")
      case "low-stock":
        return products.filter((p) => p.quantity < 10)
      default:
        return products
    }
  }

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case "Excellent":
        return "bg-green-500"
      case "Good":
        return "bg-blue-500"
      case "Fair":
        return "bg-yellow-500"
      case "Poor":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="min-h-screen gradient-page">
      <NavHeader />
      <main className="container py-8">
        <div className="mb-8 p-6 rounded-2xl bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="text-5xl hover:scale-110 transition-transform cursor-pointer bg-white/20 backdrop-blur-sm rounded-2xl p-3"
              >
                {selectedEmoji}
              </button>
              <div>
                <h1 className="text-4xl font-bold mb-2">Product Management</h1>
                <p className="text-blue-100">Comprehensive inventory tracking and asset control</p>
              </div>
            </div>
            <div className="flex space-x-3">
              <Dialog open={isScanDialogOpen} onOpenChange={setIsScanDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border-white/30 text-white">
                    <QrCode className="w-4 h-4 mr-2" />
                    Scan QR Code
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Scan QR Code</DialogTitle>
                    <DialogDescription>Enter the product SKU from QR code to view details</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="flex flex-col items-center space-y-4">
                      <div className="w-full space-y-2">
                        <Label htmlFor="sku-input">Product SKU</Label>
                        <div className="flex space-x-2">
                          <Input
                            id="sku-input"
                            placeholder="Enter SKU (e.g., MCB-450)"
                            value={scanInput}
                            onChange={(e) => setScanInput(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") {
                                handleScanQR()
                              }
                            }}
                          />
                          <Button onClick={handleScanQR}>
                            <Search className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="w-full border-t pt-4">
                        <p className="text-sm text-muted-foreground text-center mb-3">Or use camera/upload</p>
                        <div className="flex space-x-2">
                          <Button variant="outline" className="flex-1 bg-transparent">
                            <Camera className="w-4 h-4 mr-2" />
                            Camera
                          </Button>
                          <Button variant="outline" className="flex-1 bg-transparent">
                            <Upload className="w-4 h-4 mr-2" />
                            Upload
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-white hover:bg-white/90 text-indigo-600 font-semibold shadow-lg">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Product
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Product</DialogTitle>
                    <DialogDescription>Enter the details of the electrical asset</DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-2 gap-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Product Name *</Label>
                      <Input
                        id="name"
                        placeholder="Circuit Breaker MCB-450"
                        value={newProduct.name || ""}
                        onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="sku">SKU *</Label>
                      <Input
                        id="sku"
                        placeholder="MCB-450"
                        value={newProduct.sku || ""}
                        onChange={(e) => setNewProduct({ ...newProduct, sku: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="category">Category</Label>
                      <Input
                        id="category"
                        placeholder="Circuit Protection"
                        value={newProduct.category || ""}
                        onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="quantity">Quantity</Label>
                      <Input
                        id="quantity"
                        type="number"
                        placeholder="0"
                        value={newProduct.quantity || ""}
                        onChange={(e) =>
                          setNewProduct({ ...newProduct, quantity: Number.parseInt(e.target.value) || 0 })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        placeholder="Warehouse A - Shelf 12"
                        value={newProduct.location || ""}
                        onChange={(e) => setNewProduct({ ...newProduct, location: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="supplier">Supplier</Label>
                      <Input
                        id="supplier"
                        placeholder="ABB Ltd."
                        value={newProduct.supplier || ""}
                        onChange={(e) => setNewProduct({ ...newProduct, supplier: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="purchaseDate">Purchase Date</Label>
                      <Input
                        id="purchaseDate"
                        type="date"
                        value={newProduct.purchaseDate || ""}
                        onChange={(e) => setNewProduct({ ...newProduct, purchaseDate: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="condition">Condition</Label>
                      <Select
                        value={newProduct.condition}
                        onValueChange={(value) =>
                          setNewProduct({ ...newProduct, condition: value as Product["condition"] })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Excellent">Excellent</SelectItem>
                          <SelectItem value="Good">Good</SelectItem>
                          <SelectItem value="Fair">Fair</SelectItem>
                          <SelectItem value="Poor">Poor</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddProduct}>Add Product</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {showEmojiPicker && (
            <div className="mt-4 p-4 bg-white/10 backdrop-blur-md rounded-xl border border-white/20">
              <p className="text-sm text-blue-100 mb-3 font-medium">Choose your page icon:</p>
              <div className="grid grid-cols-8 gap-3">
                {PAGE_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => {
                      setSelectedEmoji(emoji)
                      setShowEmojiPicker(false)
                    }}
                    className="text-3xl hover:scale-125 transition-transform bg-white/20 hover:bg-white/30 rounded-lg p-2"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card
            className="cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1 border-0 overflow-hidden"
            onClick={() => handleViewCategory("total")}
          >
            <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <Package className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Total Products</p>
              <p className="text-4xl font-bold mb-2">{products.length}</p>
              <p className="text-xs opacity-75 bg-white/20 inline-block px-2 py-1 rounded-full">Click to view all</p>
            </div>
          </Card>
          <Card className="border-0 overflow-hidden hover:shadow-lg transition-shadow">
            <div className="bg-gradient-to-br from-purple-500 to-pink-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <Package className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Total Quantity</p>
              <p className="text-4xl font-bold">{products.reduce((sum, p) => sum + p.quantity, 0)}</p>
            </div>
          </Card>
          <Card
            className="cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1 border-0 overflow-hidden"
            onClick={() => handleViewCategory("active")}
          >
            <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <Package className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Active Items</p>
              <p className="text-4xl font-bold mb-2">{products.filter((p) => p.status === "Active").length}</p>
              <p className="text-xs opacity-75 bg-white/20 inline-block px-2 py-1 rounded-full">Click to view all</p>
            </div>
          </Card>
          <Card
            className="cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1 border-0 overflow-hidden"
            onClick={() => handleViewCategory("low-stock")}
          >
            <div className="bg-gradient-to-br from-amber-500 to-orange-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <AlertCircle className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Low Stock</p>
              <p className="text-4xl font-bold mb-2">{products.filter((p) => p.quantity < 10).length}</p>
              <p className="text-xs opacity-75 bg-white/20 inline-block px-2 py-1 rounded-full">Click to view all</p>
            </div>
          </Card>
        </div>

        <Card className="mb-6 border-0 shadow-lg">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search products by name, SKU, or category..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-2 focus:border-blue-500"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product Name</TableHead>
                  <TableHead>SKU</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Supplier</TableHead>
                  <TableHead>Condition</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>QR Code</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{product.sku}</Badge>
                    </TableCell>
                    <TableCell>{product.category}</TableCell>
                    <TableCell>
                      <span className={product.quantity < 10 ? "text-yellow-600 font-semibold" : ""}>
                        {product.quantity}
                      </span>
                    </TableCell>
                    <TableCell>{product.location}</TableCell>
                    <TableCell>{product.supplier}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <div className={`w-2 h-2 rounded-full ${getConditionColor(product.condition)}`} />
                        <span className="text-sm">{product.condition}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={product.status === "Active" ? "default" : "secondary"}>{product.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewProduct(product)}
                        className="text-primary hover:text-primary/80"
                      >
                        <QrCode className="w-4 h-4 mr-1" />
                        View
                      </Button>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="ghost" size="icon">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteProduct(product.id)}>
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Dialog open={!!scannedProduct} onOpenChange={() => setScannedProduct(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <QrCode className="w-5 h-5 text-primary" />
                <span>Scanned Product Details</span>
              </DialogTitle>
            </DialogHeader>
            {scannedProduct && (
              <div className="space-y-6">
                <div className="flex items-start space-x-6">
                  <div className="flex-shrink-0">
                    {scannedProduct.qrCodeUrl ? (
                      <img
                        src={scannedProduct.qrCodeUrl || "/placeholder.svg"}
                        alt={`QR Code for ${scannedProduct.sku}`}
                        className="w-32 h-32 border-2 border-border rounded-lg"
                      />
                    ) : (
                      <div className="w-32 h-32 border-2 border-border rounded-lg flex items-center justify-center bg-muted">
                        <QrCode className="w-16 h-16 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-3">
                      <h3 className="text-xl font-bold">{scannedProduct.name}</h3>
                      <Badge variant="outline" className="text-base">
                        {scannedProduct.sku}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Category</p>
                        <p className="font-medium">{scannedProduct.category}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Quantity</p>
                        <p className={`font-medium ${scannedProduct.quantity < 10 ? "text-yellow-600" : ""}`}>
                          {scannedProduct.quantity} units
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Location</p>
                        <p className="font-medium">{scannedProduct.location}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Supplier</p>
                        <p className="font-medium">{scannedProduct.supplier}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Purchase Date</p>
                        <p className="font-medium">{new Date(scannedProduct.purchaseDate).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Condition</p>
                        <div className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full ${getConditionColor(scannedProduct.condition)}`} />
                          <span className="font-medium">{scannedProduct.condition}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Status</p>
                        <Badge variant={scannedProduct.status === "Active" ? "default" : "secondary"}>
                          {scannedProduct.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex justify-end space-x-2 pt-4 border-t">
                  <Button variant="outline" onClick={() => setScannedProduct(null)}>
                    Close
                  </Button>
                  {scannedProduct.qrCodeUrl && (
                    <Button asChild>
                      <a href={scannedProduct.qrCodeUrl} download={`QR-${scannedProduct.sku}.jpg`}>
                        Download QR Code
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={isProductDetailOpen} onOpenChange={setIsProductDetailOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Package className="w-5 h-5 text-primary" />
                <span>Product Details & QR Code</span>
              </DialogTitle>
            </DialogHeader>
            {selectedProduct && (
              <div className="space-y-6">
                <div className="flex items-start space-x-6">
                  <div className="flex-shrink-0">
                    {selectedProduct.qrCodeUrl ? (
                      <img
                        src={selectedProduct.qrCodeUrl || "/placeholder.svg"}
                        alt={`QR Code for ${selectedProduct.sku}`}
                        className="w-32 h-32 border-2 border-border rounded-lg"
                      />
                    ) : (
                      <div className="w-32 h-32 border-2 border-border rounded-lg flex items-center justify-center bg-muted">
                        <QrCode className="w-16 h-16 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-3">
                      <h3 className="text-xl font-bold">{selectedProduct.name}</h3>
                      <Badge variant="outline" className="text-base">
                        {selectedProduct.sku}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Category</p>
                        <p className="font-medium">{selectedProduct.category}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Quantity</p>
                        <p className={`font-medium ${selectedProduct.quantity < 10 ? "text-yellow-600" : ""}`}>
                          {selectedProduct.quantity} units
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Location</p>
                        <p className="font-medium">{selectedProduct.location}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Supplier</p>
                        <p className="font-medium">{selectedProduct.supplier}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Purchase Date</p>
                        <p className="font-medium">{new Date(selectedProduct.purchaseDate).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Condition</p>
                        <div className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full ${getConditionColor(selectedProduct.condition)}`} />
                          <span className="font-medium">{selectedProduct.condition}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Status</p>
                        <Badge variant={selectedProduct.status === "Active" ? "default" : "secondary"}>
                          {selectedProduct.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex justify-end space-x-2 pt-4 border-t">
                  <Button variant="outline" onClick={() => setIsProductDetailOpen(false)}>
                    Close
                  </Button>
                  {selectedProduct.qrCodeUrl && (
                    <Button asChild>
                      <a href={selectedProduct.qrCodeUrl} download={`QR-${selectedProduct.sku}.jpg`}>
                        Download QR Code
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
