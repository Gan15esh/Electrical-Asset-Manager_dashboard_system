"use client"

import { useState, useMemo } from "react"
import { NavHeader } from "@/components/nav-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  Calendar,
  FileText,
  DollarSign,
  AlertCircle,
  CheckCircle,
  Clock,
  Download,
  QrCode,
  Shield,
  Sparkles,
  TrendingUp,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

interface PaymentDetails {
  invoiceNumber: string
  invoiceDate: string
  warrantyEndDate: string
  totalAmount: number
  paymentReceived: number
  warrantyStatus: "Under Warranty" | "Active Warranty" | "Pending Warranty"
  emoji: string
  assetName: string
  assetCategory: string
  manufacturer: string
}

const emojiOptions = ["⚡", "🔌", "💡", "🔋", "⚙️", "🏭", "🔧", "🛠️", "📊", "💼", "📈", "✅", "🎯", "🚀", "💎", "⭐"]

export default function PaymentsPage() {
  const [payment, setPayment] = useState<PaymentDetails>({
    invoiceNumber: "01",
    invoiceDate: "2026-01-08",
    warrantyEndDate: "2028-01-07",
    totalAmount: 100000,
    paymentReceived: 20000,
    warrantyStatus: "Active Warranty",
    emoji: "⚡",
    assetName: "High Voltage Transformer - 500KVA",
    assetCategory: "Power Distribution",
    manufacturer: "Electric Corp Industries",
  })

  const [showQR, setShowQR] = useState(false)

  const dueDate = useMemo(() => {
    const invoiceDate = new Date(payment.invoiceDate)
    const calculatedDueDate = new Date(invoiceDate)
    calculatedDueDate.setDate(calculatedDueDate.getDate() + 45)
    return calculatedDueDate.toISOString().split("T")[0]
  }, [payment.invoiceDate])

  const outstandingBalance = payment.totalAmount - payment.paymentReceived
  const paymentProgress = (payment.paymentReceived / payment.totalAmount) * 100

  const warrantyTimeRemaining = useMemo(() => {
    const today = new Date()
    const endDate = new Date(payment.warrantyEndDate)
    const diffTime = endDate.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays > 0 ? diffDays : 0
  }, [payment.warrantyEndDate])

  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString("en-IN")}`
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const getWarrantyBadgeStyle = () => {
    switch (payment.warrantyStatus) {
      case "Active Warranty":
        return "bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0"
      case "Under Warranty":
        return "bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-0"
      case "Pending Warranty":
        return "bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0"
      default:
        return ""
    }
  }

  const qrCodeData = useMemo(() => {
    return JSON.stringify({
      invoiceNumber: payment.invoiceNumber,
      assetName: payment.assetName,
      category: payment.assetCategory,
      manufacturer: payment.manufacturer,
      totalAmount: payment.totalAmount,
      paymentReceived: payment.paymentReceived,
      outstanding: outstandingBalance,
      warrantyStatus: payment.warrantyStatus,
      warrantyEndDate: payment.warrantyEndDate,
      dueDate: formatDate(dueDate),
    })
  }, [payment, outstandingBalance, dueDate])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      <NavHeader />
      <main className="container py-8 max-w-7xl">
        <div className="mb-8 relative overflow-hidden rounded-2xl bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 p-8 text-white shadow-2xl">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
          <div className="relative flex items-center justify-between">
            <div>
              <div className="flex items-center gap-4 mb-3">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="secondary"
                      className="text-4xl h-16 w-16 hover:scale-110 transition-transform bg-white/20 hover:bg-white/30 border-2 border-white/40"
                    >
                      {payment.emoji}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto">
                    <div className="grid grid-cols-8 gap-2">
                      {emojiOptions.map((emoji) => (
                        <Button
                          key={emoji}
                          variant="ghost"
                          className="text-2xl h-12 w-12 hover:scale-125 transition-transform"
                          onClick={() => setPayment({ ...payment, emoji })}
                        >
                          {emoji}
                        </Button>
                      ))}
                    </div>
                  </PopoverContent>
                </Popover>
                <div>
                  <h1 className="text-4xl font-bold mb-1 flex items-center gap-3">
                    Payment Management
                    <Sparkles className="w-8 h-8 animate-pulse" />
                  </h1>
                  <p className="text-white/90 text-lg">Track invoices, payments & warranties with ease</p>
                </div>
              </div>
            </div>
            <Dialog open={showQR} onOpenChange={setShowQR}>
              <DialogTrigger asChild>
                <Button
                  size="lg"
                  className="bg-white text-purple-600 hover:bg-white/90 shadow-lg hover:shadow-xl transition-all hover:scale-105"
                >
                  <QrCode className="w-5 h-5 mr-2" />
                  View QR Code
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle className="text-2xl flex items-center gap-2">
                    <QrCode className="w-6 h-6 text-primary" />
                    Asset QR Code
                  </DialogTitle>
                  <DialogDescription>Scan this QR code to view complete product details</DialogDescription>
                </DialogHeader>
                <div className="space-y-6">
                  <div className="flex flex-col items-center justify-center p-8 bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950/20 dark:to-blue-950/20 rounded-xl">
                    <div className="bg-white p-6 rounded-2xl shadow-2xl">
                      <img
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qrCodeData)}`}
                        alt="Asset QR Code"
                        className="w-64 h-64"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground mt-4">Scan to access full asset information</p>
                  </div>

                  <div className="border-t pt-6">
                    <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-primary" />
                      Product Details
                    </h3>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="space-y-3">
                        <div>
                          <Label className="text-xs text-muted-foreground">Asset Name</Label>
                          <p className="font-medium">{payment.assetName}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">Category</Label>
                          <p className="font-medium">{payment.assetCategory}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">Manufacturer</Label>
                          <p className="font-medium">{payment.manufacturer}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">Invoice Number</Label>
                          <p className="font-medium">#{payment.invoiceNumber}</p>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div>
                          <Label className="text-xs text-muted-foreground">Total Amount</Label>
                          <p className="font-medium text-lg">{formatCurrency(payment.totalAmount)}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">Payment Received</Label>
                          <p className="font-medium text-green-600">{formatCurrency(payment.paymentReceived)}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">Outstanding Balance</Label>
                          <p className="font-medium text-red-600">{formatCurrency(outstandingBalance)}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">Warranty Status</Label>
                          <Badge className={getWarrantyBadgeStyle()}>{payment.warrantyStatus}</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Invoice & Payment Details */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-blue-50/50 dark:from-slate-900 dark:to-blue-950/20 overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-2xl" />
              <CardHeader className="relative">
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500">
                    <FileText className="w-5 h-5 text-white" />
                  </div>
                  Invoice Details
                </CardTitle>
                <CardDescription>Manage your invoice information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 relative">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="invoiceNumber" className="text-muted-foreground font-medium">
                      Invoice Number
                    </Label>
                    <Input
                      id="invoiceNumber"
                      value={payment.invoiceNumber}
                      onChange={(e) => setPayment({ ...payment, invoiceNumber: e.target.value })}
                      className="font-semibold text-lg border-2 focus:border-blue-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="invoiceDate" className="text-muted-foreground font-medium flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Invoice Date
                    </Label>
                    <Input
                      id="invoiceDate"
                      type="date"
                      value={payment.invoiceDate}
                      onChange={(e) => setPayment({ ...payment, invoiceDate: e.target.value })}
                      className="border-2 focus:border-blue-500"
                    />
                  </div>
                </div>

                <div className="p-6 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 rounded-xl border-2 border-amber-200 dark:border-amber-900 shadow-md">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-3 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 shadow-lg">
                        <Clock className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="text-base font-semibold text-amber-900 dark:text-amber-100">
                          Due Date (Auto-calculated)
                        </p>
                        <p className="text-sm text-amber-700 dark:text-amber-400">Invoice Date + 45 Days</p>
                      </div>
                    </div>
                    <Badge className="text-lg font-bold px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                      {formatDate(dueDate)}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-purple-50/50 dark:from-slate-900 dark:to-purple-950/20 overflow-hidden">
              <div className="absolute top-0 left-0 w-40 h-40 bg-gradient-to-br from-purple-400/20 to-pink-400/20 rounded-full blur-3xl" />
              <CardHeader className="relative border-b-4 border-gradient-to-r from-purple-500 to-pink-500">
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500">
                    <DollarSign className="w-5 h-5 text-white" />
                  </div>
                  Financial Summary
                </CardTitle>
                <CardDescription>Track payments and outstanding balances</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6 relative">
                <div className="grid grid-cols-1 gap-6">
                  <div className="p-6 bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900 rounded-xl shadow-lg">
                    <Label className="text-xs text-muted-foreground uppercase tracking-wide font-semibold">
                      Total Amount
                    </Label>
                    <div className="flex items-baseline gap-2 mt-3">
                      <span className="text-4xl font-bold bg-gradient-to-r from-slate-700 to-slate-900 dark:from-slate-100 dark:to-slate-300 bg-clip-text text-transparent">
                        {formatCurrency(payment.totalAmount)}
                      </span>
                      <TrendingUp className="w-6 h-6 text-slate-600" />
                    </div>
                    <Input
                      type="number"
                      value={payment.totalAmount}
                      onChange={(e) => setPayment({ ...payment, totalAmount: Number(e.target.value) })}
                      className="mt-3 border-2"
                    />
                  </div>

                  <div className="p-6 bg-gradient-to-br from-green-100 to-emerald-100 dark:from-green-950/40 dark:to-emerald-950/40 rounded-xl border-2 border-green-300 dark:border-green-800 shadow-lg">
                    <Label className="text-xs text-green-800 dark:text-green-300 uppercase tracking-wide font-semibold flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      Payment Received
                    </Label>
                    <div className="flex items-baseline gap-3 mt-3">
                      <span className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                        {formatCurrency(payment.paymentReceived)}
                      </span>
                    </div>
                    <Input
                      type="number"
                      value={payment.paymentReceived}
                      onChange={(e) => setPayment({ ...payment, paymentReceived: Number(e.target.value) })}
                      className="mt-3 border-2 border-green-300"
                    />
                  </div>

                  <div className="p-6 bg-gradient-to-br from-red-100 to-rose-100 dark:from-red-950/40 dark:to-rose-950/40 rounded-xl border-2 border-red-300 dark:border-red-800 shadow-lg">
                    <Label className="text-xs text-red-800 dark:text-red-300 uppercase tracking-wide font-semibold flex items-center gap-2">
                      <AlertCircle className="w-4 h-4" />
                      Outstanding Balance
                    </Label>
                    <div className="flex items-baseline gap-3 mt-3">
                      <span className="text-4xl font-bold bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent">
                        {formatCurrency(outstandingBalance)}
                      </span>
                    </div>
                    <p className="text-sm text-red-700 dark:text-red-400 mt-3 font-medium">
                      {outstandingBalance > 0 ? "⏳ Payment pending" : "✅ Fully paid"}
                    </p>
                  </div>
                </div>

                <Separator className="my-6" />

                <div className="space-y-4 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 rounded-xl">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-lg flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-blue-600" />
                      Payment Progress
                    </span>
                    <Badge className="text-base px-3 py-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white border-0">
                      {paymentProgress.toFixed(1)}%
                    </Badge>
                  </div>
                  <Progress value={paymentProgress} className="h-4 bg-slate-200 dark:bg-slate-700" />
                  <p className="text-sm text-muted-foreground">
                    {paymentProgress === 100
                      ? "🎉 Invoice fully paid - Thank you!"
                      : `💰 ${formatCurrency(outstandingBalance)} remaining to complete payment`}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Warranty & Actions */}
          <div className="space-y-6">
            <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-green-50/50 dark:from-slate-900 dark:to-green-950/20 overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-400/20 to-emerald-400/20 rounded-full blur-2xl" />
              <CardHeader className="relative">
                <CardTitle className="flex items-center gap-2 text-xl">
                  <div className="p-2 rounded-lg bg-gradient-to-br from-green-500 to-emerald-500">
                    <Shield className="w-5 h-5 text-white" />
                  </div>
                  Warranty Information
                </CardTitle>
                <CardDescription>Manage asset warranty details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 relative">
                {/* Warranty End Date */}
                <div className="space-y-2">
                  <Label htmlFor="warrantyEndDate" className="text-muted-foreground font-medium">
                    Warranty End Date
                  </Label>
                  <Input
                    id="warrantyEndDate"
                    type="date"
                    value={payment.warrantyEndDate}
                    onChange={(e) => setPayment({ ...payment, warrantyEndDate: e.target.value })}
                    className="border-2 focus:border-green-500"
                  />
                </div>

                <Separator />

                <div className="space-y-4">
                  <Label className="text-sm font-semibold flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Warranty Status
                  </Label>
                  <Select
                    value={payment.warrantyStatus}
                    onValueChange={(value: typeof payment.warrantyStatus) =>
                      setPayment({ ...payment, warrantyStatus: value })
                    }
                  >
                    <SelectTrigger className="border-2 h-14 text-base font-medium">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Under Warranty" className="text-base">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500" />
                          <span>Under Warranty</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="Active Warranty" className="text-base">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 animate-pulse" />
                          <span>Active Warranty</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="Pending Warranty" className="text-base">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-gradient-to-r from-amber-500 to-orange-500" />
                          <span>Pending Warranty</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>

                  <div className="flex items-center justify-center p-4 rounded-xl bg-gradient-to-r from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900">
                    <Badge className={`${getWarrantyBadgeStyle()} text-base px-4 py-2 shadow-lg`}>
                      {payment.warrantyStatus}
                    </Badge>
                  </div>

                  <p className="text-xs text-muted-foreground text-center">
                    {payment.warrantyStatus === "Active Warranty" && "✅ Warranty is currently active and valid"}
                    {payment.warrantyStatus === "Under Warranty" && "🛡️ Asset is covered under warranty protection"}
                    {payment.warrantyStatus === "Pending Warranty" && "⏳ Warranty activation is pending"}
                  </p>
                </div>

                <Separator />

                <div className="p-6 bg-gradient-to-br from-emerald-100 to-teal-100 dark:from-emerald-950/40 dark:to-teal-950/40 rounded-xl border-2 border-emerald-300 dark:border-emerald-800 shadow-md">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-semibold flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Time Remaining
                    </span>
                    <Badge
                      className={`${
                        warrantyTimeRemaining > 180
                          ? "bg-gradient-to-r from-green-500 to-emerald-500"
                          : "bg-gradient-to-r from-red-500 to-rose-500"
                      } text-white border-0 px-3 py-1 text-base`}
                    >
                      {warrantyTimeRemaining} days
                    </Badge>
                  </div>
                  <Progress
                    value={Math.min((warrantyTimeRemaining / 730) * 100, 100)}
                    className="h-3 bg-slate-200 dark:bg-slate-700"
                  />
                  <p className="text-xs text-emerald-800 dark:text-emerald-300 mt-3 font-medium">
                    📅 Warranty expires on {formatDate(payment.warrantyEndDate)}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-indigo-50/50 dark:from-slate-900 dark:to-indigo-950/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600" />
                  Quick Actions
                </CardTitle>
                <CardDescription>Asset and document management</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start h-12 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white border-0 shadow-lg hover:shadow-xl transition-all hover:scale-105">
                  <FileText className="w-4 h-4 mr-2" />
                  View Asset Datasheet
                </Button>
                <Button className="w-full justify-start h-12 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white border-0 shadow-lg hover:shadow-xl transition-all hover:scale-105">
                  <Download className="w-4 h-4 mr-2" />
                  Download Invoice PDF
                </Button>
                <Button className="w-full justify-start h-12 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white border-0 shadow-lg hover:shadow-xl transition-all hover:scale-105">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Record Payment
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-600 text-white border-0 shadow-2xl overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-white/20 rounded-full blur-2xl" />
              <CardHeader className="relative">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  Payment Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 relative">
                <div className="flex justify-between items-center">
                  <span className="text-white/80">Invoice #</span>
                  <span className="font-bold text-lg">{payment.invoiceNumber}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white/80">Payment Status</span>
                  <Badge
                    className={`${
                      outstandingBalance === 0 ? "bg-green-500 hover:bg-green-600" : "bg-amber-500 hover:bg-amber-600"
                    } text-white border-0`}
                  >
                    {outstandingBalance === 0 ? "✅ Paid" : "⏳ Partial"}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white/80">Warranty</span>
                  <Badge className="bg-white/20 hover:bg-white/30 text-white border-white/40">
                    {payment.warrantyStatus}
                  </Badge>
                </div>
                <Separator className="bg-white/20" />
                <div className="pt-2">
                  <p className="text-xs text-white/70 text-center">Last updated: {new Date().toLocaleDateString()}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
