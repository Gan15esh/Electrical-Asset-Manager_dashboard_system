import { NextResponse } from "next/server"
import { query } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET() {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    // Get total payments count
    const totalResult = await query<any[]>("SELECT COUNT(*) as count FROM payments WHERE user_id = ?", [user!.userId])
    const totalPayments = totalResult[0]?.count || 0

    // Calculate total amount
    const payments = await query<any[]>("SELECT amount FROM payments WHERE user_id = ?", [user!.userId])

    const totalAmount = payments.reduce((sum, payment) => sum + Number.parseFloat(payment.amount || 0), 0)

    return NextResponse.json({
      totalPayments,
      completedPayments: totalPayments, // All payments in this system are considered completed
      totalAmount: Math.round(totalAmount * 100) / 100,
      completedAmount: Math.round(totalAmount * 100) / 100,
    })
  } catch (err) {
    console.error("Error fetching payment stats:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
