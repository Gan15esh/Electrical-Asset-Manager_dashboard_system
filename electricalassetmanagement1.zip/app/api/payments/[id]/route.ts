import { NextResponse, type NextRequest } from "next/server"
import { query, queryOne } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params

    const payment = await queryOne<any>("SELECT * FROM payments WHERE id = ? AND user_id = ?", [id, user!.userId])

    if (!payment) {
      return NextResponse.json({ error: "Payment not found" }, { status: 404 })
    }

    return NextResponse.json(payment)
  } catch (err) {
    console.error("Error fetching payment:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params
    const body = await request.json()

    const { invoice_id, payment_date, amount, payment_method, reference_number, notes } = body

    await query(
      `UPDATE payments SET invoice_id = ?, payment_date = ?, amount = ?, payment_method = ?, 
       reference_number = ?, notes = ? 
       WHERE id = ? AND user_id = ?`,
      [invoice_id, payment_date, amount, payment_method, reference_number, notes, id, user!.userId],
    )

    const updatedPayment = await queryOne<any>("SELECT * FROM payments WHERE id = ?", [id])

    return NextResponse.json(updatedPayment)
  } catch (err) {
    console.error("Error updating payment:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params

    await query("DELETE FROM payments WHERE id = ? AND user_id = ?", [id, user!.userId])

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error("Error deleting payment:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
