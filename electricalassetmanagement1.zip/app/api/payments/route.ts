import { NextResponse, type NextRequest } from "next/server"
import { query } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET(request: NextRequest) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { searchParams } = new URL(request.url)
    const invoiceId = searchParams.get("invoice_id")
    const paymentMethod = searchParams.get("payment_method")

    let sql = "SELECT * FROM payments WHERE user_id = ?"
    const params: any[] = [user!.userId]

    if (invoiceId) {
      sql += " AND invoice_id = ?"
      params.push(invoiceId)
    }
    if (paymentMethod) {
      sql += " AND payment_method = ?"
      params.push(paymentMethod)
    }

    sql += " ORDER BY payment_date DESC"

    const payments = await query<any[]>(sql, params)

    return NextResponse.json(payments)
  } catch (err) {
    console.error("Error fetching payments:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const body = await request.json()
    const { invoice_id, payment_date, amount, payment_method, reference_number, notes } = body

    // Validate required fields
    if (!payment_date || amount === undefined || !payment_method) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Create payment
    const result = await query<any>(
      `INSERT INTO payments (user_id, invoice_id, payment_date, amount, payment_method, reference_number, notes) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [user!.userId, invoice_id || null, payment_date, amount, payment_method, reference_number || null, notes || null],
    )

    // If payment is associated with an invoice, update invoice status to paid
    if (invoice_id) {
      await query("UPDATE invoices SET status = 'paid' WHERE id = ? AND user_id = ?", [invoice_id, user!.userId])
    }

    const newPayment = await query<any[]>("SELECT * FROM payments WHERE id = ?", [result.insertId])

    return NextResponse.json(newPayment[0], { status: 201 })
  } catch (err) {
    console.error("Error creating payment:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
