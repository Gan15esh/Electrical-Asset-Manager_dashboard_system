import { NextResponse } from "next/server"
import { query } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET() {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    // Get total invoices
    const totalResult = await query<any[]>("SELECT COUNT(*) as count FROM invoices WHERE user_id = ?", [user!.userId])
    const totalInvoices = totalResult[0]?.count || 0

    // Get pending invoices
    const pendingResult = await query<any[]>(
      "SELECT COUNT(*) as count FROM invoices WHERE user_id = ? AND status = 'sent'",
      [user!.userId],
    )
    const pendingInvoices = pendingResult[0]?.count || 0

    // Get paid invoices
    const paidResult = await query<any[]>(
      "SELECT COUNT(*) as count FROM invoices WHERE user_id = ? AND status = 'paid'",
      [user!.userId],
    )
    const paidInvoices = paidResult[0]?.count || 0

    // Get overdue invoices
    const overdueResult = await query<any[]>(
      "SELECT COUNT(*) as count FROM invoices WHERE user_id = ? AND status = 'overdue'",
      [user!.userId],
    )
    const overdueInvoices = overdueResult[0]?.count || 0

    // Calculate total amounts
    const allInvoices = await query<any[]>("SELECT total, status FROM invoices WHERE user_id = ?", [user!.userId])

    const totalAmount = allInvoices.reduce((sum, inv) => sum + Number.parseFloat(inv.total || 0), 0)
    const pendingAmount = allInvoices
      .filter((inv) => inv.status === "sent")
      .reduce((sum, inv) => sum + Number.parseFloat(inv.total || 0), 0)
    const paidAmount = allInvoices
      .filter((inv) => inv.status === "paid")
      .reduce((sum, inv) => sum + Number.parseFloat(inv.total || 0), 0)

    return NextResponse.json({
      totalInvoices,
      pendingInvoices,
      paidInvoices,
      overdueInvoices,
      totalAmount: Math.round(totalAmount * 100) / 100,
      pendingAmount: Math.round(pendingAmount * 100) / 100,
      paidAmount: Math.round(paidAmount * 100) / 100,
    })
  } catch (err) {
    console.error("Error fetching invoice stats:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
