import { NextResponse, type NextRequest } from "next/server"
import { query, queryOne } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params

    const invoice = await queryOne<any>("SELECT * FROM invoices WHERE id = ? AND user_id = ?", [id, user!.userId])

    if (!invoice) {
      return NextResponse.json({ error: "Invoice not found" }, { status: 404 })
    }

    // Get invoice items
    const items = await query<any[]>("SELECT * FROM invoice_items WHERE invoice_id = ?", [id])

    return NextResponse.json({ ...invoice, items })
  } catch (err) {
    console.error("Error fetching invoice:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params
    const body = await request.json()

    const {
      invoice_number,
      customer_name,
      customer_email,
      issue_date,
      due_date,
      subtotal,
      tax,
      total,
      status,
      notes,
      items,
    } = body

    await query(
      `UPDATE invoices SET invoice_number = ?, customer_name = ?, customer_email = ?, issue_date = ?, 
       due_date = ?, subtotal = ?, tax = ?, total = ?, status = ?, notes = ? 
       WHERE id = ? AND user_id = ?`,
      [
        invoice_number,
        customer_name,
        customer_email,
        issue_date,
        due_date,
        subtotal,
        tax,
        total,
        status,
        notes,
        id,
        user!.userId,
      ],
    )

    // Update invoice items if provided
    if (items && Array.isArray(items)) {
      // Delete existing items
      await query("DELETE FROM invoice_items WHERE invoice_id = ?", [id])

      // Insert new items
      for (const item of items) {
        await query(
          `INSERT INTO invoice_items (invoice_id, product_id, description, quantity, unit_price, total) 
           VALUES (?, ?, ?, ?, ?, ?)`,
          [id, item.product_id || null, item.description, item.quantity, item.unit_price, item.total],
        )
      }
    }

    const updatedInvoice = await queryOne<any>("SELECT * FROM invoices WHERE id = ?", [id])
    const invoiceItems = await query<any[]>("SELECT * FROM invoice_items WHERE invoice_id = ?", [id])

    return NextResponse.json({ ...updatedInvoice, items: invoiceItems })
  } catch (err) {
    console.error("Error updating invoice:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params

    // Delete invoice items first (foreign key constraint)
    await query("DELETE FROM invoice_items WHERE invoice_id = ?", [id])

    // Delete invoice
    await query("DELETE FROM invoices WHERE id = ? AND user_id = ?", [id, user!.userId])

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error("Error deleting invoice:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
