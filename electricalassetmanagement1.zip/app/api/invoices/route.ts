import { NextResponse, type NextRequest } from "next/server"
import { query } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET(request: NextRequest) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const customerName = searchParams.get("customer_name")

    let sql = "SELECT * FROM invoices WHERE user_id = ?"
    const params: any[] = [user!.userId]

    if (status) {
      sql += " AND status = ?"
      params.push(status)
    }
    if (customerName) {
      sql += " AND customer_name LIKE ?"
      params.push(`%${customerName}%`)
    }

    sql += " ORDER BY issue_date DESC"

    const invoices = await query<any[]>(sql, params)

    return NextResponse.json(invoices)
  } catch (err) {
    console.error("Error fetching invoices:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const body = await request.json()
    const {
      invoice_number,
      customer_name,
      customer_email,
      issue_date,
      due_date,
      subtotal,
      tax,
      total,
      status,
      notes,
      items,
    } = body

    // Validate required fields
    if (!invoice_number || !issue_date || !due_date || subtotal === undefined || total === undefined) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Create invoice
    const result = await query<any>(
      `INSERT INTO invoices (user_id, invoice_number, customer_name, customer_email, issue_date, due_date, 
       subtotal, tax, total, status, notes) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        user!.userId,
        invoice_number,
        customer_name || null,
        customer_email || null,
        issue_date,
        due_date,
        subtotal,
        tax || 0,
        total,
        status || "draft",
        notes || null,
      ],
    )

    const invoiceId = result.insertId

    // Create invoice items if provided
    if (items && Array.isArray(items) && items.length > 0) {
      for (const item of items) {
        await query(
          `INSERT INTO invoice_items (invoice_id, product_id, description, quantity, unit_price, total) 
           VALUES (?, ?, ?, ?, ?, ?)`,
          [invoiceId, item.product_id || null, item.description, item.quantity, item.unit_price, item.total],
        )
      }
    }

    // Fetch the complete invoice with items
    const newInvoice = await query<any[]>("SELECT * FROM invoices WHERE id = ?", [invoiceId])
    const invoiceItems = await query<any[]>("SELECT * FROM invoice_items WHERE invoice_id = ?", [invoiceId])

    return NextResponse.json({ ...newInvoice[0], items: invoiceItems }, { status: 201 })
  } catch (err) {
    console.error("Error creating invoice:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
