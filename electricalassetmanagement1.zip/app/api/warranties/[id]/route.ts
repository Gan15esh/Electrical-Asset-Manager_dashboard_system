import { NextResponse, type NextRequest } from "next/server"
import { query, queryOne } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params

    const warranty = await queryOne<any>("SELECT * FROM warranties WHERE id = ? AND user_id = ?", [id, user!.userId])

    if (!warranty) {
      return NextResponse.json({ error: "Warranty not found" }, { status: 404 })
    }

    return NextResponse.json(warranty)
  } catch (err) {
    console.error("Error fetching warranty:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params
    const body = await request.json()

    const { product_id, warranty_number, provider, start_date, end_date, coverage_type, terms, status } = body

    await query(
      `UPDATE warranties SET product_id = ?, warranty_number = ?, provider = ?, start_date = ?, 
       end_date = ?, coverage_type = ?, terms = ?, status = ? 
       WHERE id = ? AND user_id = ?`,
      [product_id, warranty_number, provider, start_date, end_date, coverage_type, terms, status, id, user!.userId],
    )

    const updatedWarranty = await queryOne<any>("SELECT * FROM warranties WHERE id = ?", [id])

    return NextResponse.json(updatedWarranty)
  } catch (err) {
    console.error("Error updating warranty:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params

    await query("DELETE FROM warranties WHERE id = ? AND user_id = ?", [id, user!.userId])

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error("Error deleting warranty:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
