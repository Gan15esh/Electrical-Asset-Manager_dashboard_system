import { NextResponse, type NextRequest } from "next/server"
import { query } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET(request: NextRequest) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const provider = searchParams.get("provider")

    let sql = "SELECT * FROM warranties WHERE user_id = ?"
    const params: any[] = [user!.userId]

    if (status) {
      sql += " AND status = ?"
      params.push(status)
    }
    if (provider) {
      sql += " AND provider = ?"
      params.push(provider)
    }

    sql += " ORDER BY end_date ASC"

    const warranties = await query<any[]>(sql, params)

    return NextResponse.json(warranties)
  } catch (err) {
    console.error("Error fetching warranties:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const body = await request.json()
    const { product_id, warranty_number, provider, start_date, end_date, coverage_type, terms, status } = body

    // Validate required fields
    if (!start_date || !end_date) {
      return NextResponse.json({ error: "Start date and end date are required" }, { status: 400 })
    }

    const result = await query<any>(
      `INSERT INTO warranties (user_id, product_id, warranty_number, provider, start_date, end_date, 
       coverage_type, terms, status) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        user!.userId,
        product_id || null,
        warranty_number || null,
        provider || null,
        start_date,
        end_date,
        coverage_type || null,
        terms || null,
        status || "active",
      ],
    )

    const newWarranty = await query<any[]>("SELECT * FROM warranties WHERE id = ?", [result.insertId])

    return NextResponse.json(newWarranty[0], { status: 201 })
  } catch (err) {
    console.error("Error creating warranty:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
