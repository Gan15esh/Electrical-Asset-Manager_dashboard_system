import { NextResponse } from "next/server"
import { query } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET() {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    // Get total warranties count
    const totalResult = await query<any[]>("SELECT COUNT(*) as count FROM warranties WHERE user_id = ?", [user!.userId])
    const totalWarranties = totalResult[0]?.count || 0

    // Get active warranties count
    const activeResult = await query<any[]>(
      "SELECT COUNT(*) as count FROM warranties WHERE user_id = ? AND status = 'active'",
      [user!.userId],
    )
    const activeWarranties = activeResult[0]?.count || 0

    // Get expired warranties count
    const expiredResult = await query<any[]>(
      "SELECT COUNT(*) as count FROM warranties WHERE user_id = ? AND status = 'expired'",
      [user!.userId],
    )
    const expiredWarranties = expiredResult[0]?.count || 0

    // Get warranties expiring soon (within 30 days)
    const today = new Date().toISOString().split("T")[0]
    const thirtyDaysFromNow = new Date()
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30)
    const futureDate = thirtyDaysFromNow.toISOString().split("T")[0]

    const expiringSoonResult = await query<any[]>(
      "SELECT COUNT(*) as count FROM warranties WHERE user_id = ? AND status = 'active' AND end_date >= ? AND end_date <= ?",
      [user!.userId, today, futureDate],
    )
    const expiringSoon = expiringSoonResult[0]?.count || 0

    return NextResponse.json({
      totalWarranties,
      activeWarranties,
      expiredWarranties,
      expiringSoon,
    })
  } catch (err) {
    console.error("Error fetching warranty stats:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
