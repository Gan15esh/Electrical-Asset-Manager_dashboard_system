import { NextResponse } from "next/server"
import { query } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET() {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    // Get total products count
    const totalResult = await query<any[]>("SELECT COUNT(*) as count FROM products WHERE user_id = ?", [user!.userId])
    const totalProducts = totalResult[0]?.count || 0

    // Get active products count
    const activeResult = await query<any[]>(
      "SELECT COUNT(*) as count FROM products WHERE user_id = ? AND status = 'active'",
      [user!.userId],
    )
    const activeProducts = activeResult[0]?.count || 0

    // Get total inventory value
    const valueResult = await query<any[]>(
      "SELECT SUM(purchase_price) as total FROM products WHERE user_id = ? AND purchase_price IS NOT NULL",
      [user!.userId],
    )
    const totalValue = valueResult[0]?.total || 0

    // Get products by category
    const categoryResult = await query<any[]>(
      "SELECT category, COUNT(*) as count FROM products WHERE user_id = ? GROUP BY category",
      [user!.userId],
    )

    const categoryStats = categoryResult.reduce(
      (acc, row) => {
        if (row.category) {
          acc[row.category] = row.count
        }
        return acc
      },
      {} as Record<string, number>,
    )

    return NextResponse.json({
      totalProducts,
      activeProducts,
      totalValue: Math.round(totalValue * 100) / 100,
      categoryStats,
    })
  } catch (err) {
    console.error("Error fetching product stats:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
