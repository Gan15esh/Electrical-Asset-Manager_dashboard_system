import { NextResponse, type NextRequest } from "next/server"
import { query, queryOne } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params

    const product = await queryOne<any>("SELECT * FROM products WHERE id = ? AND user_id = ?", [id, user!.userId])

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    return NextResponse.json(product)
  } catch (err) {
    console.error("Error fetching product:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params
    const body = await request.json()

    const {
      name,
      category,
      model_number,
      serial_number,
      manufacturer,
      purchase_date,
      purchase_price,
      location,
      status,
      notes,
    } = body

    await query(
      `UPDATE products SET name = ?, category = ?, model_number = ?, serial_number = ?, 
       manufacturer = ?, purchase_date = ?, purchase_price = ?, location = ?, status = ?, notes = ? 
       WHERE id = ? AND user_id = ?`,
      [
        name,
        category,
        model_number,
        serial_number,
        manufacturer,
        purchase_date,
        purchase_price,
        location,
        status,
        notes,
        id,
        user!.userId,
      ],
    )

    const updatedProduct = await queryOne<any>("SELECT * FROM products WHERE id = ?", [id])

    return NextResponse.json(updatedProduct)
  } catch (err) {
    console.error("Error updating product:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { id } = await params

    await query("DELETE FROM products WHERE id = ? AND user_id = ?", [id, user!.userId])

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error("Error deleting product:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
