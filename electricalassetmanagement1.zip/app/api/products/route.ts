import { NextResponse, type NextRequest } from "next/server"
import { query } from "@/lib/db/mysql"
import { requireAuth } from "@/lib/auth/middleware"

export async function GET(request: NextRequest) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const status = searchParams.get("status")
    const manufacturer = searchParams.get("manufacturer")

    let sql = "SELECT * FROM products WHERE user_id = ?"
    const params: any[] = [user!.userId]

    if (category) {
      sql += " AND category = ?"
      params.push(category)
    }
    if (status) {
      sql += " AND status = ?"
      params.push(status)
    }
    if (manufacturer) {
      sql += " AND manufacturer = ?"
      params.push(manufacturer)
    }

    sql += " ORDER BY created_at DESC"

    const products = await query<any[]>(sql, params)

    return NextResponse.json(products)
  } catch (err) {
    console.error("Error fetching products:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const { error, user } = await requireAuth()
  if (error) return error

  try {
    const body = await request.json()
    const {
      name,
      category,
      model_number,
      serial_number,
      manufacturer,
      purchase_date,
      purchase_price,
      location,
      status,
      notes,
    } = body

    // Validate required fields
    if (!name) {
      return NextResponse.json({ error: "Product name is required" }, { status: 400 })
    }

    const result = await query<any>(
      `INSERT INTO products (user_id, name, category, model_number, serial_number, manufacturer, 
       purchase_date, purchase_price, location, status, notes) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        user!.userId,
        name,
        category || null,
        model_number || null,
        serial_number || null,
        manufacturer || null,
        purchase_date || null,
        purchase_price || null,
        location || null,
        status || "active",
        notes || null,
      ],
    )

    const newProduct = await query<any[]>("SELECT * FROM products WHERE id = ?", [result.insertId])

    return NextResponse.json(newProduct[0], { status: 201 })
  } catch (err) {
    console.error("Error creating product:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
