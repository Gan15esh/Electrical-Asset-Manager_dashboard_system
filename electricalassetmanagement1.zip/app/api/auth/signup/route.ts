import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/db/mysql"
import { hashPassword, validatePassword } from "@/lib/auth/password"
import { signToken, setAuthCookie } from "@/lib/auth/jwt"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password, fullName, companyName, phone } = body

    // Validate required fields
    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400 })
    }

    // Validate password strength
    const passwordValidation = validatePassword(password)
    if (!passwordValidation.valid) {
      return NextResponse.json({ error: passwordValidation.error }, { status: 400 })
    }

    // Check if user already exists
    const existingUser = await query<any[]>("SELECT id FROM users WHERE email = ?", [email])

    if (existingUser.length > 0) {
      return NextResponse.json({ error: "User with this email already exists" }, { status: 409 })
    }

    // Hash password
    const passwordHash = await hashPassword(password)

    // Create user
    const result = await query<any>(
      `INSERT INTO users (email, password_hash, full_name, company_name, phone, role) 
       VALUES (?, ?, ?, ?, ?, 'user')`,
      [email, passwordHash, fullName || null, companyName || null, phone || null],
    )

    const userId = result.insertId

    // Generate JWT token
    const token = signToken({
      userId,
      email,
      role: "user",
    })

    // Set auth cookie
    await setAuthCookie(token)

    return NextResponse.json(
      {
        message: "User created successfully",
        user: {
          id: userId,
          email,
          fullName: fullName || null,
          role: "user",
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Signup error:", error)
    return NextResponse.json({ error: "An error occurred during signup" }, { status: 500 })
  }
}
