import { NextResponse } from "next/server"
import { getCurrentUser } from "@/lib/auth/jwt"
import { query } from "@/lib/db/mysql"

export async function GET() {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user details from database
    const users = await query<any[]>(
      "SELECT id, email, full_name, company_name, phone, role, created_at FROM users WHERE id = ?",
      [currentUser.userId],
    )

    if (users.length === 0) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const user = users[0]

    return NextResponse.json({
      id: user.id,
      email: user.email,
      fullName: user.full_name,
      companyName: user.company_name,
      phone: user.phone,
      role: user.role,
      createdAt: user.created_at,
    })
  } catch (error) {
    console.error("Get user error:", error)
    return NextResponse.json({ error: "An error occurred while fetching user" }, { status: 500 })
  }
}
