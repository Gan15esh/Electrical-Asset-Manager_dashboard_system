"use client"

import { useState } from "react"
import { NavHeader } from "@/components/nav-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { QrCode, Download, Search, Eye, Package, MapPin, Calendar } from "lucide-react"

interface QRCodeData {
  id: string
  productName: string
  sku: string
  qrCodeUrl: string
  generatedDate: string
  location: string
  scans: number
  lastScanned?: string
}

const mockQRCodes: QRCodeData[] = [
  {
    id: "1",
    productName: "Circuit Breaker MCB-450",
    sku: "MCB-450",
    qrCodeUrl: "/qr-code-mcb-450.jpg",
    generatedDate: "2024-01-15",
    location: "Warehouse A - Shelf 12",
    scans: 24,
    lastScanned: "2024-03-10",
  },
  {
    id: "2",
    productName: "Transformer TR-8820",
    sku: "TR-8820",
    qrCodeUrl: "/qr-code-tr-8820.jpg",
    generatedDate: "2023-11-20",
    location: "Warehouse B - Bay 3",
    scans: 15,
    lastScanned: "2024-03-08",
  },
  {
    id: "3",
    productName: "Cable Wire CW-2200",
    sku: "CW-2200",
    qrCodeUrl: "/qr-code-cw-2200.jpg",
    generatedDate: "2024-02-10",
    location: "Warehouse A - Shelf 5",
    scans: 32,
    lastScanned: "2024-03-12",
  },
  {
    id: "4",
    productName: "Panel Board PB-1150",
    sku: "PB-1150",
    qrCodeUrl: "/qr-code-pb-1150.jpg",
    generatedDate: "2023-12-05",
    location: "Warehouse C - Section 2",
    scans: 19,
    lastScanned: "2024-03-09",
  },
]

const PAGE_EMOJIS = ["📱", "🔍", "📲", "⚡", "💎", "🎯", "🚀", "✨", "🔧", "⚙️", "📊", "💼", "🏆", "✅", "📦", "🔒"]

export default function QRCodesPage() {
  const [qrCodes, setQrCodes] = useState<QRCodeData[]>(mockQRCodes)
  const [searchQuery, setSearchQuery] = useState("")
  const [isGenerateDialogOpen, setIsGenerateDialogOpen] = useState(false)
  const [selectedQR, setSelectedQR] = useState<QRCodeData | null>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [newQRData, setNewQRData] = useState({
    productName: "",
    sku: "",
    location: "",
    additionalInfo: "",
  })
  const [selectedEmoji, setSelectedEmoji] = useState("📱")
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)

  const filteredQRCodes = qrCodes.filter(
    (qr) =>
      qr.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      qr.sku.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleGenerateQR = () => {
    if (newQRData.productName && newQRData.sku) {
      const newQR: QRCodeData = {
        id: (qrCodes.length + 1).toString(),
        productName: newQRData.productName,
        sku: newQRData.sku,
        qrCodeUrl: `/placeholder.svg?height=200&width=200&query=QR+code+${newQRData.sku}`,
        generatedDate: new Date().toISOString().split("T")[0],
        location: newQRData.location,
        scans: 0,
      }
      setQrCodes([...qrCodes, newQR])
      setIsGenerateDialogOpen(false)
      setNewQRData({ productName: "", sku: "", location: "", additionalInfo: "" })
    }
  }

  const handleViewQR = (qr: QRCodeData) => {
    setSelectedQR(qr)
    setIsViewDialogOpen(true)
  }

  const handleDownloadQR = (qr: QRCodeData) => {
    // Mock download functionality
    console.log("[v0] Downloading QR code for:", qr.sku)
  }

  return (
    <div className="min-h-screen gradient-page">
      <NavHeader />
      <main className="container py-8">
        <div className="mb-8 p-6 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="text-5xl hover:scale-110 transition-transform cursor-pointer bg-white/20 backdrop-blur-sm rounded-2xl p-3"
              >
                {selectedEmoji}
              </button>
              <div>
                <h1 className="text-4xl font-bold mb-2">QR Code Management</h1>
                <p className="text-pink-100">Generate, scan, and track QR codes for instant asset identification</p>
              </div>
            </div>
            <Dialog open={isGenerateDialogOpen} onOpenChange={setIsGenerateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-white hover:bg-white/90 text-purple-600 font-semibold shadow-lg">
                  <QrCode className="w-4 h-4 mr-2" />
                  Generate QR Code
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Generate New QR Code</DialogTitle>
                  <DialogDescription>Create a QR code for asset tracking and identification</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="productName">Product Name *</Label>
                    <Input
                      id="productName"
                      placeholder="Circuit Breaker MCB-450"
                      value={newQRData.productName}
                      onChange={(e) => setNewQRData({ ...newQRData, productName: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sku">SKU *</Label>
                    <Input
                      id="sku"
                      placeholder="MCB-450"
                      value={newQRData.sku}
                      onChange={(e) => setNewQRData({ ...newQRData, sku: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      placeholder="Warehouse A - Shelf 12"
                      value={newQRData.location}
                      onChange={(e) => setNewQRData({ ...newQRData, location: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="additionalInfo">Additional Information</Label>
                    <Textarea
                      id="additionalInfo"
                      placeholder="Add any additional details..."
                      value={newQRData.additionalInfo}
                      onChange={(e) => setNewQRData({ ...newQRData, additionalInfo: e.target.value })}
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsGenerateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleGenerateQR}>Generate QR Code</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {showEmojiPicker && (
            <div className="mt-4 p-4 bg-white/10 backdrop-blur-md rounded-xl border border-white/20">
              <p className="text-sm text-pink-100 mb-3 font-medium">Choose your page icon:</p>
              <div className="grid grid-cols-8 gap-3">
                {PAGE_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => {
                      setSelectedEmoji(emoji)
                      setShowEmojiPicker(false)
                    }}
                    className="text-3xl hover:scale-125 transition-transform bg-white/20 hover:bg-white/30 rounded-lg p-2"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card className="border-0 overflow-hidden hover:shadow-lg transition-shadow">
            <div className="bg-gradient-to-br from-purple-500 to-indigo-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <QrCode className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Total QR Codes</p>
              <p className="text-4xl font-bold">{qrCodes.length}</p>
              <p className="text-xs opacity-75">Active QR codes</p>
            </div>
          </Card>
          <Card className="border-0 overflow-hidden hover:shadow-lg transition-shadow">
            <div className="bg-gradient-to-br from-pink-500 to-rose-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <Eye className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Total Scans</p>
              <p className="text-4xl font-bold">{qrCodes.reduce((sum, qr) => sum + qr.scans, 0)}</p>
              <p className="text-xs opacity-75">Cumulative scans</p>
            </div>
          </Card>
          <Card className="border-0 overflow-hidden hover:shadow-lg transition-shadow">
            <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <Package className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Avg. Scans</p>
              <p className="text-4xl font-bold">
                {qrCodes.length > 0 ? Math.round(qrCodes.reduce((sum, qr) => sum + qr.scans, 0) / qrCodes.length) : 0}
              </p>
              <p className="text-xs opacity-75">Per QR code</p>
            </div>
          </Card>
        </div>

        <Card className="mb-6 border-0 shadow-lg">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search QR codes by product name or SKU..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredQRCodes.map((qr) => (
            <Card
              key={qr.id}
              className="border-0 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1 overflow-hidden"
            >
              <div className="bg-gradient-to-br from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 p-4">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg truncate text-purple-900 dark:text-purple-100">
                      {qr.productName}
                    </CardTitle>
                    <div className="mt-2">
                      <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white border-0">
                        {qr.sku}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* QR Code Image */}
                <div className="flex justify-center p-4 bg-white dark:bg-gray-800 rounded-xl shadow-inner">
                  <img src={qr.qrCodeUrl || "/placeholder.svg"} alt={`QR code for ${qr.sku}`} className="w-32 h-32" />
                </div>
              </div>

              <CardContent className="space-y-4 p-4">
                {/* Details */}
                <div className="space-y-2 text-sm">
                  <div className="flex items-center text-muted-foreground">
                    <MapPin className="w-4 h-4 mr-2 text-purple-600" />
                    <span className="truncate">{qr.location}</span>
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <Calendar className="w-4 h-4 mr-2 text-pink-600" />
                    <span>Generated: {qr.generatedDate}</span>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-border">
                    <span className="text-muted-foreground">Scans</span>
                    <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white border-0">
                      {qr.scans}
                    </Badge>
                  </div>
                  {qr.lastScanned && (
                    <div className="text-xs text-muted-foreground">Last scanned: {qr.lastScanned}</div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex space-x-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 border-purple-600 text-purple-600 hover:bg-purple-50 bg-transparent"
                    onClick={() => handleViewQR(qr)}
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    View
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 border-pink-600 text-pink-600 hover:bg-pink-50 bg-transparent"
                    onClick={() => handleDownloadQR(qr)}
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* View QR Dialog */}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{selectedQR?.productName}</DialogTitle>
              <DialogDescription>QR Code Details</DialogDescription>
            </DialogHeader>
            {selectedQR && (
              <div className="space-y-4">
                <div className="flex justify-center p-6 bg-muted rounded-lg">
                  <img
                    src={selectedQR.qrCodeUrl || "/placeholder.svg"}
                    alt={`QR code for ${selectedQR.sku}`}
                    className="w-48 h-48"
                  />
                </div>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">SKU:</span>
                    <Badge variant="outline">{selectedQR.sku}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Location:</span>
                    <span className="font-medium">{selectedQR.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Generated:</span>
                    <span className="font-medium">{selectedQR.generatedDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Scans:</span>
                    <Badge>{selectedQR.scans}</Badge>
                  </div>
                  {selectedQR.lastScanned && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Last Scanned:</span>
                      <span className="font-medium">{selectedQR.lastScanned}</span>
                    </div>
                  )}
                </div>
                <Button className="w-full" onClick={() => handleDownloadQR(selectedQR)}>
                  <Download className="w-4 h-4 mr-2" />
                  Download QR Code
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
