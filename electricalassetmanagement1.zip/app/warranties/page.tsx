"use client"

import { useState } from "react"
import { NavHeader } from "@/components/nav-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, Eye, Shield, AlertTriangle, CheckCircle2, Clock } from "lucide-react"
import { Progress } from "@/components/ui/progress"

interface Warranty {
  id: string
  productName: string
  sku: string
  supplier: string
  purchaseDate: string
  warrantyPeriod: number // in months
  expiryDate: string
  status: "Active" | "Expiring Soon" | "Expired"
  claimStatus: "None" | "In Progress" | "Completed"
  notes?: string
}

const mockWarranties: Warranty[] = [
  {
    id: "1",
    productName: "Circuit Breaker MCB-450",
    sku: "MCB-450",
    supplier: "ABB Ltd.",
    purchaseDate: "2024-01-15",
    warrantyPeriod: 24,
    expiryDate: "2026-01-15",
    status: "Active",
    claimStatus: "None",
    notes: "Standard manufacturer warranty",
  },
  {
    id: "2",
    productName: "Transformer TR-8820",
    sku: "TR-8820",
    supplier: "Siemens",
    purchaseDate: "2023-11-20",
    warrantyPeriod: 12,
    expiryDate: "2024-11-20",
    status: "Expiring Soon",
    claimStatus: "None",
    notes: "Extended warranty available",
  },
  {
    id: "3",
    productName: "Cable Wire CW-2200",
    sku: "CW-2200",
    supplier: "Havells",
    purchaseDate: "2022-02-10",
    warrantyPeriod: 12,
    expiryDate: "2023-02-10",
    status: "Expired",
    claimStatus: "None",
  },
  {
    id: "4",
    productName: "Panel Board PB-1150",
    sku: "PB-1150",
    supplier: "Schneider Electric",
    purchaseDate: "2023-12-05",
    warrantyPeriod: 36,
    expiryDate: "2026-12-05",
    status: "Active",
    claimStatus: "None",
    notes: "3-year premium warranty",
  },
  {
    id: "5",
    productName: "Junction Box JB-200",
    sku: "JB-200",
    supplier: "Legrand",
    purchaseDate: "2024-01-25",
    warrantyPeriod: 18,
    expiryDate: "2025-07-25",
    status: "Active",
    claimStatus: "In Progress",
    notes: "Claim submitted for minor defect",
  },
]

const PAGE_EMOJIS = ["🛡️", "✅", "⚠️", "🔒", "📋", "🎯", "💼", "📊", "🏆", "⚡", "🔧", "✨", "🚀", "💎", "🔐", "📦"]

export default function WarrantiesPage() {
  const [warranties, setWarranties] = useState<Warranty[]>(mockWarranties)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedWarranty, setSelectedWarranty] = useState<Warranty | null>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [isStatsDialogOpen, setIsStatsDialogOpen] = useState(false)
  const [newWarranty, setNewWarranty] = useState<Partial<Warranty>>({
    status: "Active",
    claimStatus: "None",
    warrantyPeriod: 12,
  })
  const [selectedEmoji, setSelectedEmoji] = useState("🛡️")
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)

  const filteredWarranties = warranties.filter((warranty) => {
    const matchesSearch =
      warranty.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      warranty.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      warranty.supplier.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || warranty.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const calculateExpiryDate = (purchaseDate: string, warrantyPeriod: number) => {
    const date = new Date(purchaseDate)
    date.setMonth(date.getMonth() + warrantyPeriod)
    return date.toISOString().split("T")[0]
  }

  const calculateRemainingMonths = (expiryDate: string) => {
    const today = new Date()
    const expiry = new Date(expiryDate)
    const diffTime = expiry.getTime() - today.getTime()
    const diffMonths = Math.ceil(diffTime / (1000 * 60 * 60 * 24 * 30))
    return diffMonths
  }

  const handleAddWarranty = () => {
    if (newWarranty.productName && newWarranty.sku && newWarranty.purchaseDate && newWarranty.warrantyPeriod) {
      const expiryDate = calculateExpiryDate(newWarranty.purchaseDate, newWarranty.warrantyPeriod)
      const remainingMonths = calculateRemainingMonths(expiryDate)
      const status: Warranty["status"] =
        remainingMonths < 0 ? "Expired" : remainingMonths <= 3 ? "Expiring Soon" : "Active"

      const warranty: Warranty = {
        id: (warranties.length + 1).toString(),
        productName: newWarranty.productName,
        sku: newWarranty.sku,
        supplier: newWarranty.supplier || "",
        purchaseDate: newWarranty.purchaseDate,
        warrantyPeriod: newWarranty.warrantyPeriod,
        expiryDate,
        status,
        claimStatus: "None",
        notes: newWarranty.notes,
      }
      setWarranties([...warranties, warranty])
      setIsAddDialogOpen(false)
      setNewWarranty({ status: "Active", claimStatus: "None", warrantyPeriod: 12 })
    }
  }

  const handleViewWarranty = (warranty: Warranty) => {
    setSelectedWarranty(warranty)
    setIsViewDialogOpen(true)
  }

  const handleViewCategory = (category: string) => {
    setSelectedCategory(category)
    setIsStatsDialogOpen(true)
  }

  const getCategoryWarranties = () => {
    switch (selectedCategory) {
      case "active":
        return warranties.filter((w) => w.status === "Active")
      case "expiring":
        return warranties.filter((w) => w.status === "Expiring Soon")
      case "expired":
        return warranties.filter((w) => w.status === "Expired")
      case "claims":
        return warranties.filter((w) => w.claimStatus === "In Progress")
      default:
        return warranties
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-500"
      case "Expiring Soon":
        return "bg-yellow-500"
      case "Expired":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getWarrantyProgress = (warranty: Warranty) => {
    const purchaseDate = new Date(warranty.purchaseDate)
    const expiryDate = new Date(warranty.expiryDate)
    const today = new Date()

    const totalTime = expiryDate.getTime() - purchaseDate.getTime()
    const elapsedTime = today.getTime() - purchaseDate.getTime()
    const progress = Math.min(Math.max((elapsedTime / totalTime) * 100, 0), 100)

    return progress
  }

  const activeCount = filteredWarranties.filter((w) => w.status === "Active").length
  const expiringSoonCount = filteredWarranties.filter((w) => w.status === "Expiring Soon").length
  const expiredCount = filteredWarranties.filter((w) => w.status === "Expired").length
  const claimsInProgress = filteredWarranties.filter((w) => w.claimStatus === "In Progress").length

  return (
    <div className="min-h-screen gradient-page">
      <NavHeader />
      <main className="container py-8">
        <div className="mb-8 p-6 rounded-2xl bg-gradient-to-r from-emerald-600 via-green-600 to-teal-600 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="text-5xl hover:scale-110 transition-transform cursor-pointer bg-white/20 backdrop-blur-sm rounded-2xl p-3"
              >
                {selectedEmoji}
              </button>
              <div>
                <h1 className="text-4xl font-bold mb-2">Warranty Management</h1>
                <p className="text-green-100">Track warranties, monitor expiration, and manage claims</p>
              </div>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-white hover:bg-white/90 text-emerald-600 font-semibold shadow-lg">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Warranty
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Register New Warranty</DialogTitle>
                  <DialogDescription>Enter warranty details for tracking</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="productName">Product Name *</Label>
                    <Input
                      id="productName"
                      placeholder="Circuit Breaker MCB-450"
                      value={newWarranty.productName || ""}
                      onChange={(e) => setNewWarranty({ ...newWarranty, productName: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sku">SKU *</Label>
                    <Input
                      id="sku"
                      placeholder="MCB-450"
                      value={newWarranty.sku || ""}
                      onChange={(e) => setNewWarranty({ ...newWarranty, sku: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="supplier">Supplier</Label>
                    <Input
                      id="supplier"
                      placeholder="ABB Ltd."
                      value={newWarranty.supplier || ""}
                      onChange={(e) => setNewWarranty({ ...newWarranty, supplier: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="purchaseDate">Purchase Date *</Label>
                      <Input
                        id="purchaseDate"
                        type="date"
                        value={newWarranty.purchaseDate || ""}
                        onChange={(e) => setNewWarranty({ ...newWarranty, purchaseDate: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="warrantyPeriod">Warranty Period (Months) *</Label>
                      <Input
                        id="warrantyPeriod"
                        type="number"
                        placeholder="12"
                        value={newWarranty.warrantyPeriod || ""}
                        onChange={(e) =>
                          setNewWarranty({ ...newWarranty, warrantyPeriod: Number.parseInt(e.target.value) })
                        }
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea
                      id="notes"
                      placeholder="Additional warranty information..."
                      value={newWarranty.notes || ""}
                      onChange={(e) => setNewWarranty({ ...newWarranty, notes: e.target.value })}
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddWarranty}>Add Warranty</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {showEmojiPicker && (
            <div className="mt-4 p-4 bg-white/10 backdrop-blur-md rounded-xl border border-white/20">
              <p className="text-sm text-green-100 mb-3 font-medium">Choose your page icon:</p>
              <div className="grid grid-cols-8 gap-3">
                {PAGE_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => {
                      setSelectedEmoji(emoji)
                      setShowEmojiPicker(false)
                    }}
                    className="text-3xl hover:scale-125 transition-transform bg-white/20 hover:bg-white/30 rounded-lg p-2"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card
            className="cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1 border-0 overflow-hidden"
            onClick={() => handleViewCategory("active")}
          >
            <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <CheckCircle2 className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Active Warranties</p>
              <p className="text-4xl font-bold mb-2">{activeCount}</p>
              <p className="text-xs opacity-75 bg-white/20 inline-block px-2 py-1 rounded-full">Click to view all</p>
            </div>
          </Card>
          <Card
            className="cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1 border-0 overflow-hidden"
            onClick={() => handleViewCategory("expiring")}
          >
            <div className="bg-gradient-to-br from-amber-500 to-orange-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <AlertTriangle className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Expiring Soon</p>
              <p className="text-4xl font-bold mb-2">{expiringSoonCount}</p>
              <p className="text-xs opacity-75 bg-white/20 inline-block px-2 py-1 rounded-full">Click to view all</p>
            </div>
          </Card>
          <Card
            className="cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1 border-0 overflow-hidden"
            onClick={() => handleViewCategory("expired")}
          >
            <div className="bg-gradient-to-br from-red-500 to-rose-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <Shield className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Expired</p>
              <p className="text-4xl font-bold mb-2">{expiredCount}</p>
              <p className="text-xs opacity-75 bg-white/20 inline-block px-2 py-1 rounded-full">Click to view all</p>
            </div>
          </Card>
          <Card
            className="cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1 border-0 overflow-hidden"
            onClick={() => handleViewCategory("claims")}
          >
            <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <Clock className="w-10 h-10 opacity-90" />
              </div>
              <p className="text-sm opacity-90 mb-1">Active Claims</p>
              <p className="text-4xl font-bold mb-2">{claimsInProgress}</p>
              <p className="text-xs opacity-75 bg-white/20 inline-block px-2 py-1 rounded-full">Click to view all</p>
            </div>
          </Card>
        </div>

        <Card className="mb-6 border-0 shadow-lg">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="Search by product name, SKU, or supplier..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Expiring Soon">Expiring Soon</SelectItem>
                  <SelectItem value="Expired">Expired</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product Name</TableHead>
                  <TableHead>SKU</TableHead>
                  <TableHead>Supplier</TableHead>
                  <TableHead>Purchase Date</TableHead>
                  <TableHead>Expiry Date</TableHead>
                  <TableHead>Progress</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Claim Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredWarranties.map((warranty) => {
                  const remainingMonths = calculateRemainingMonths(warranty.expiryDate)
                  const progress = getWarrantyProgress(warranty)
                  return (
                    <TableRow key={warranty.id}>
                      <TableCell className="font-medium">{warranty.productName}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{warranty.sku}</Badge>
                      </TableCell>
                      <TableCell>{warranty.supplier}</TableCell>
                      <TableCell>{warranty.purchaseDate}</TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="font-medium">{warranty.expiryDate}</div>
                          {remainingMonths >= 0 ? (
                            <div className="text-xs text-muted-foreground">{remainingMonths} months left</div>
                          ) : (
                            <div className="text-xs text-red-600">Expired</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="w-24 space-y-1">
                          <Progress value={progress} className="h-2" />
                          <div className="text-xs text-muted-foreground text-center">{Math.round(progress)}%</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full ${getStatusColor(warranty.status)}`} />
                          <Badge
                            variant={
                              warranty.status === "Active"
                                ? "default"
                                : warranty.status === "Expired"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {warranty.status}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={warranty.claimStatus === "In Progress" ? "default" : "outline"}
                          className={warranty.claimStatus === "None" ? "text-muted-foreground" : ""}
                        >
                          {warranty.claimStatus}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => handleViewWarranty(warranty)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* View Warranty Dialog */}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Warranty Details</DialogTitle>
              <DialogDescription>{selectedWarranty?.productName}</DialogDescription>
            </DialogHeader>
            {selectedWarranty && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Product Name</Label>
                    <p className="font-medium mt-1">{selectedWarranty.productName}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">SKU</Label>
                    <p className="font-medium mt-1">
                      <Badge variant="outline">{selectedWarranty.sku}</Badge>
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Supplier</Label>
                    <p className="font-medium mt-1">{selectedWarranty.supplier}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Status</Label>
                    <div className="mt-1">
                      <Badge
                        variant={
                          selectedWarranty.status === "Active"
                            ? "default"
                            : selectedWarranty.status === "Expired"
                              ? "destructive"
                              : "secondary"
                        }
                      >
                        {selectedWarranty.status}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Purchase Date</Label>
                    <p className="font-medium mt-1">{selectedWarranty.purchaseDate}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Warranty Period</Label>
                    <p className="font-medium mt-1">{selectedWarranty.warrantyPeriod} months</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Expiry Date</Label>
                    <p className="font-medium mt-1">{selectedWarranty.expiryDate}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Claim Status</Label>
                    <div className="mt-1">
                      <Badge variant={selectedWarranty.claimStatus === "In Progress" ? "default" : "outline"}>
                        {selectedWarranty.claimStatus}
                      </Badge>
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-muted-foreground">Warranty Progress</Label>
                  <div className="mt-2 space-y-2">
                    <Progress value={getWarrantyProgress(selectedWarranty)} className="h-3" />
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        {calculateRemainingMonths(selectedWarranty.expiryDate)} months remaining
                      </span>
                      <span className="font-medium">{Math.round(getWarrantyProgress(selectedWarranty))}% elapsed</span>
                    </div>
                  </div>
                </div>

                {selectedWarranty.notes && (
                  <div>
                    <Label className="text-muted-foreground">Notes</Label>
                    <p className="mt-1 text-sm">{selectedWarranty.notes}</p>
                  </div>
                )}

                <div className="flex space-x-2 pt-4 border-t border-border">
                  {selectedWarranty.claimStatus === "None" && selectedWarranty.status !== "Expired" && (
                    <Button className="flex-1">File Warranty Claim</Button>
                  )}
                  <Button className="flex-1 bg-transparent" variant="outline">
                    Download Certificate
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* View Warranties by Category Dialog */}
        <Dialog open={isStatsDialogOpen} onOpenChange={setIsStatsDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {selectedCategory === "active" && "Active Warranties"}
                {selectedCategory === "expiring" && "Warranties Expiring Soon"}
                {selectedCategory === "expired" && "Expired Warranties"}
                {selectedCategory === "claims" && "Active Claims"}
              </DialogTitle>
              <DialogDescription>
                {getCategoryWarranties().length} warranty/warranties in this category
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {getCategoryWarranties().map((warranty) => {
                const remainingMonths = calculateRemainingMonths(warranty.expiryDate)
                const progress = getWarrantyProgress(warranty)
                return (
                  <Card key={warranty.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="font-semibold text-lg">{warranty.productName}</h3>
                            <Badge variant="outline">{warranty.sku}</Badge>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-muted-foreground">Supplier</p>
                              <p className="font-medium">{warranty.supplier}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Status</p>
                              <div className="flex items-center space-x-2">
                                <div className={`w-2 h-2 rounded-full ${getStatusColor(warranty.status)}`} />
                                <Badge
                                  variant={
                                    warranty.status === "Active"
                                      ? "default"
                                      : warranty.status === "Expired"
                                        ? "destructive"
                                        : "secondary"
                                  }
                                >
                                  {warranty.status}
                                </Badge>
                              </div>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Purchase Date</p>
                              <p className="font-medium">{warranty.purchaseDate}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Expiry Date</p>
                              <div>
                                <p className="font-medium">{warranty.expiryDate}</p>
                                {remainingMonths >= 0 ? (
                                  <p className="text-xs text-muted-foreground">{remainingMonths} months left</p>
                                ) : (
                                  <p className="text-xs text-red-600">Expired</p>
                                )}
                              </div>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Warranty Period</p>
                              <p className="font-medium">{warranty.warrantyPeriod} months</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Claim Status</p>
                              <Badge
                                variant={warranty.claimStatus === "In Progress" ? "default" : "outline"}
                                className={warranty.claimStatus === "None" ? "text-muted-foreground" : ""}
                              >
                                {warranty.claimStatus}
                              </Badge>
                            </div>
                          </div>
                          {warranty.notes && (
                            <div className="mt-3">
                              <p className="text-muted-foreground text-xs">Notes</p>
                              <p className="text-sm">{warranty.notes}</p>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Warranty Progress</span>
                          <span className="font-medium">{Math.round(progress)}%</span>
                        </div>
                        <Progress value={progress} className="h-2" />
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
