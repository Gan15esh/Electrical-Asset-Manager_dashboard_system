# API Integration Guide

This guide explains how to connect your frontend pages to the backend APIs.

## Overview

All backend APIs are now set up and protected with authentication. The APIs follow RESTful conventions and return JSON responses.

## API Client

We've created a centralized API client at `lib/api/client.ts` that handles all API requests. Use it instead of making raw fetch calls.

### Import the API Client

\`\`\`typescript
import { apiClient } from "@/lib/api/client"
\`\`\`

## Available API Methods

### Products API

\`\`\`typescript
// Get all products (with optional filters)
const products = await apiClient.getProducts()
const filteredProducts = await apiClient.getProducts({ 
  category: "Motors", 
  status: "active" 
})

// Get single product
const product = await apiClient.getProduct(productId)

// Create product
const newProduct = await apiClient.createProduct({
  product_name: "Industrial Motor 5HP",
  category: "Motors",
  supplier: "ElectroSupply Inc",
  quantity: 10,
  unit_price: 450.00,
  location: "Warehouse A",
  status: "active"
})

// Update product
const updatedProduct = await apiClient.updateProduct(productId, {
  quantity: 15,
  unit_price: 475.00
})

// Delete product
await apiClient.deleteProduct(productId)

// Get product statistics
const stats = await apiClient.getProductStats()
// Returns: { totalProducts, activeProducts, totalValue, categoryStats }
\`\`\`

### Warranties API

\`\`\`typescript
// Get all warranties (with optional filters)
const warranties = await apiClient.getWarranties()
const activeWarranties = await apiClient.getWarranties({ status: "active" })

// Get single warranty
const warranty = await apiClient.getWarranty(warrantyId)

// Create warranty
const newWarranty = await apiClient.createWarranty({
  product_name: "Industrial Motor 5HP",
  supplier: "ElectroSupply Inc",
  warranty_start_date: "2024-01-01",
  warranty_end_date: "2025-01-01",
  warranty_period: 12,
  coverage_type: "Full Coverage",
  status: "active"
})

// Update warranty
const updatedWarranty = await apiClient.updateWarranty(warrantyId, {
  status: "expired"
})

// Delete warranty
await apiClient.deleteWarranty(warrantyId)

// Get warranty statistics
const stats = await apiClient.getWarrantyStats()
// Returns: { totalWarranties, activeWarranties, expiredWarranties, expiringSoon }
\`\`\`

### Invoices API

\`\`\`typescript
// Get all invoices (with optional filters)
const invoices = await apiClient.getInvoices()
const pendingInvoices = await apiClient.getInvoices({ status: "pending" })

// Get single invoice
const invoice = await apiClient.getInvoice(invoiceId)

// Create invoice
const newInvoice = await apiClient.createInvoice({
  invoice_number: "INV-2024-001",
  supplier: "ElectroSupply Inc",
  invoice_date: "2024-01-15",
  due_date: "2024-02-15",
  amount: 5000.00,
  tax: 500.00,
  status: "pending"
})

// Update invoice
const updatedInvoice = await apiClient.updateInvoice(invoiceId, {
  status: "paid"
})

// Delete invoice
await apiClient.deleteInvoice(invoiceId)

// Get invoice statistics
const stats = await apiClient.getInvoiceStats()
// Returns: { totalInvoices, pendingInvoices, paidInvoices, overdueInvoices, totalAmount, pendingAmount, paidAmount }
\`\`\`

### Payments API

\`\`\`typescript
// Get all payments (with optional filters)
const payments = await apiClient.getPayments()
const invoicePayments = await apiClient.getPayments({ invoice_id: invoiceId })

// Get single payment
const payment = await apiClient.getPayment(paymentId)

// Create payment
const newPayment = await apiClient.createPayment({
  invoice_id: invoiceId, // optional
  payment_date: "2024-01-20",
  amount: 5500.00,
  payment_method: "Bank Transfer",
  reference_number: "REF-001",
  supplier: "ElectroSupply Inc",
  status: "completed"
})

// Update payment
const updatedPayment = await apiClient.updatePayment(paymentId, {
  status: "completed"
})

// Delete payment
await apiClient.deletePayment(paymentId)

// Get payment statistics
const stats = await apiClient.getPaymentStats()
// Returns: { totalPayments, completedPayments, totalAmount, completedAmount }
\`\`\`

## Integration Pattern

Here's the recommended pattern for integrating APIs into your pages:

\`\`\`typescript
"use client"

import { useState, useEffect } from "react"
import { apiClient } from "@/lib/api/client"

export default function YourPage() {
  const [data, setData] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true)
        setError(null)
        const result = await apiClient.getProducts() // or any other API method
        setData(result)
      } catch (err) {
        console.error("Error fetching data:", err)
        setError(err instanceof Error ? err.message : "Failed to load data")
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  if (isLoading) {
    return <div>Loading...</div>
  }

  if (error) {
    return <div>Error: {error}</div>
  }

  return (
    <div>
      {/* Render your data */}
    </div>
  )
}
\`\`\`

## Error Handling

All API methods throw errors that should be caught in try-catch blocks. Errors include:

- **401 Unauthorized**: User is not logged in
- **404 Not Found**: Resource doesn't exist
- **500 Internal Server Error**: Server-side error
- **400 Bad Request**: Invalid data submitted

## Authentication

All API routes are automatically protected by authentication via the proxy middleware. If a user is not logged in, they'll be redirected to the login page.

## Environment Variables

Make sure you have these environment variables set in your `.env.local`:

\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=http://your_server_ip:8000
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000
\`\`\`

## Next Steps

1. **Update Products Page**: Connect `app/products/page.tsx` to use `apiClient.getProducts()`
2. **Update Warranties Page**: Connect `app/warranties/page.tsx` to use `apiClient.getWarranties()`
3. **Update Invoices Page**: Connect `app/invoices/page.tsx` to use `apiClient.getInvoices()`
4. **Update Payments Page**: Connect `app/payments/page.tsx` to use `apiClient.getPayments()`

Each page should follow the pattern shown above with proper loading states, error handling, and data fetching.

## Example: Complete Integration

Check `app/dashboard/page.tsx` for a complete example of how to integrate multiple API calls with loading states and error handling.
\`\`\`

\`\`\`typescript file="" isHidden
