# Self-Hosted Supabase Setup Guide

This guide will help you set up a self-hosted Supabase instance on your separate PC for the Electrical Asset Management application.

## Prerequisites

- A separate PC/server with:
  - Docker and Docker Compose installed
  - At least 4GB RAM
  - 10GB free disk space
  - Ubuntu/Debian Linux (recommended) or Windows with WSL2

## Step 1: Install Docker (if not already installed)

### On Ubuntu/Debian:
\`\`\`bash
# Update package list
sudo apt update

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo apt install docker-compose-plugin

# Add your user to docker group
sudo usermod -aG docker $USER
newgrp docker
\`\`\`

### On Windows:
- Download and install Docker Desktop from https://www.docker.com/products/docker-desktop
- Enable WSL2 integration

## Step 2: Clone Supabase

\`\`\`bash
# Clone the Supabase repository
git clone --depth 1 https://github.com/supabase/supabase
cd supabase/docker
\`\`\`

## Step 3: Configure Environment Variables

\`\`\`bash
# Copy the example env file
cp .env.example .env

# Generate secure passwords and JWT secret
# You can use this command to generate random strings:
openssl rand -base64 32

# Edit the .env file and update these important variables:
nano .env
\`\`\`

Key variables to update in `.env`:
\`\`\`
POSTGRES_PASSWORD=your_super_secret_postgres_password
JWT_SECRET=your_super_secret_jwt_token_with_at_least_32_characters
ANON_KEY=generated_anon_key
SERVICE_ROLE_KEY=generated_service_role_key
SITE_URL=http://your_server_ip:3000
\`\`\`

## Step 4: Generate API Keys

Run this command to generate your ANON_KEY and SERVICE_ROLE_KEY:

\`\`\`bash
# Install JWT CLI (if not installed)
npm install -g jsonwebtoken-cli

# Generate ANON_KEY (role: anon)
jwt sign --secret "your_jwt_secret_here" '{"role":"anon","iss":"supabase","iat":1234567890,"exp":1234567890}' --algorithm HS256

# Generate SERVICE_ROLE_KEY (role: service_role)  
jwt sign --secret "your_jwt_secret_here" '{"role":"service_role","iss":"supabase","iat":1234567890,"exp":1234567890}' --algorithm HS256
\`\`\`

Or use the Supabase JWT generator: https://supabase.com/docs/guides/self-hosting#api-keys

## Step 5: Start Supabase

\`\`\`bash
# Start all services
docker compose up -d

# Check if all containers are running
docker compose ps
\`\`\`

Services will be available at:
- Supabase Studio (Dashboard): http://localhost:3000
- PostgreSQL: localhost:5432
- API: http://localhost:8000

## Step 6: Access Supabase Studio

1. Open your browser and go to: `http://your_server_ip:3000`
2. Default login credentials are in your `.env` file:
   - Email: Set in `DASHBOARD_USERNAME` (default: supabase)
   - Password: Set in `DASHBOARD_PASSWORD` (default: this_password_is_insecure_and_should_be_updated)

## Step 7: Run Database Migrations

1. In Supabase Studio, go to the SQL Editor
2. Copy and paste the contents of `scripts/01-create-tables.sql` and run it
3. Copy and paste the contents of `scripts/02-row-level-security.sql` and run it
4. (Optional) Run `scripts/03-seed-data.sql` for sample data

Alternatively, you can run them via command line:
\`\`\`bash
# Connect to PostgreSQL
docker exec -it supabase-db psql -U postgres

# Run the SQL files
\i /path/to/scripts/01-create-tables.sql
\i /path/to/scripts/02-row-level-security.sql
\`\`\`

## Step 8: Configure Your Next.js Application

Create a `.env.local` file in your Next.js project root:

\`\`\`env
# Replace with your server's IP address or domain
NEXT_PUBLIC_SUPABASE_URL=http://your_server_ip:8000
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_from_env_file

# Optional: For email confirmation redirects during development
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000
\`\`\`

## Step 9: Configure Email (Optional but Recommended)

For production use, configure SMTP settings in your `.env` file:

\`\`\`env
SMTP_ADMIN_EMAIL=admin@yourdomain.com
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password
\`\`\`

## Step 10: Test the Connection

1. Start your Next.js application: `npm run dev`
2. Go to the signup page and create a test account
3. Check if you can login successfully

## Troubleshooting

### Cannot connect to database:
- Check if all Docker containers are running: `docker compose ps`
- Check Docker logs: `docker compose logs`

### Port conflicts:
- If ports 3000, 5432, or 8000 are already in use, update them in `docker-compose.yml`

### Authentication errors:
- Verify your JWT_SECRET, ANON_KEY, and SERVICE_ROLE_KEY match in both `.env` and your Next.js `.env.local`

### Email confirmation not working:
- For development, you can disable email confirmation in Supabase Studio:
  - Go to Authentication > Settings
  - Disable "Enable email confirmations"

## Security Recommendations

1. **Change default passwords** in the `.env` file
2. **Use strong JWT secrets** (at least 32 characters)
3. **Enable firewall** on your server and only open necessary ports
4. **Use HTTPS** in production with a reverse proxy (nginx/Caddy)
5. **Regular backups** of your PostgreSQL database
6. **Keep Docker images updated**: `docker compose pull && docker compose up -d`

## Backup Your Database

\`\`\`bash
# Backup
docker exec supabase-db pg_dump -U postgres postgres > backup.sql

# Restore
docker exec -i supabase-db psql -U postgres postgres < backup.sql
\`\`\`

## Need Help?

- Supabase Self-Hosting Docs: https://supabase.com/docs/guides/self-hosting
- Supabase Discord: https://discord.supabase.com
