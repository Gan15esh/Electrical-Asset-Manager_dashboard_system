-- Sample seed data for testing
USE electrical_assets;

-- Note: Password for test user is 'password123' (will be hashed by the application)
-- Sample products
INSERT INTO products (user_id, name, category, model_number, serial_number, manufacturer, purchase_date, purchase_price, location, status, notes) VALUES
(1, 'Industrial Generator', 'Power Generation', 'GEN-5000X', 'SN123456789', 'PowerTech Industries', '2023-01-15', 15000.00, 'Building A - Room 101', 'active', 'Primary backup generator'),
(1, 'Circuit Breaker Panel', 'Distribution', 'CB-400A', 'SN987654321', 'ElectroSafe', '2023-03-20', 3500.00, 'Building A - Electrical Room', 'active', 'Main distribution panel'),
(1, 'UPS System', 'Power Protection', 'UPS-10KVA', 'SN456789123', 'PowerGuard', '2023-06-10', 8000.00, 'Server Room', 'active', '10KVA online UPS');

-- Sample warranties
INSERT INTO warranties (user_id, product_id, warranty_number, provider, start_date, end_date, coverage_type, status) VALUES
(1, 1, 'WR-2023-001', 'PowerTech Industries', '2023-01-15', '2026-01-15', 'Full Coverage', 'active'),
(1, 2, 'WR-2023-002', 'ElectroSafe', '2023-03-20', '2025-03-20', 'Parts Only', 'active'),
(1, 3, 'WR-2023-003', 'PowerGuard', '2023-06-10', '2028-06-10', 'Full Coverage', 'active');

-- Sample invoices
INSERT INTO invoices (user_id, invoice_number, customer_name, customer_email, issue_date, due_date, subtotal, tax, total, status) VALUES
(1, 'INV-2024-001', 'ABC Manufacturing', 'billing@abcmfg.com', '2024-01-01', '2024-01-31', 5000.00, 500.00, 5500.00, 'paid'),
(1, 'INV-2024-002', 'XYZ Corporation', 'accounts@xyzcorp.com', '2024-02-01', '2024-03-01', 3000.00, 300.00, 3300.00, 'sent');

-- Sample invoice items
INSERT INTO invoice_items (invoice_id, product_id, description, quantity, unit_price, total) VALUES
(1, 1, 'Generator Maintenance Service', 1, 5000.00, 5000.00),
(2, 2, 'Circuit Breaker Installation', 1, 3000.00, 3000.00);

-- Sample payments
INSERT INTO payments (user_id, invoice_id, payment_date, amount, payment_method, reference_number) VALUES
(1, 1, '2024-01-25', 5500.00, 'bank_transfer', 'TRX-20240125-001');

-- Sample maintenance records
INSERT INTO maintenance_records (user_id, product_id, maintenance_date, maintenance_type, technician, description, cost, next_maintenance_date) VALUES
(1, 1, '2024-06-15', 'preventive', 'John Smith', 'Regular maintenance and oil change', 500.00, '2024-12-15'),
(1, 3, '2024-08-20', 'inspection', 'Jane Doe', 'Annual UPS inspection and battery test', 200.00, '2025-08-20');
