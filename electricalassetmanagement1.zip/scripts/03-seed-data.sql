-- This file contains sample data for testing (optional)
-- You can modify or remove this based on your needs

-- Note: Users are created through Supabase Auth, not directly inserted here

-- Sample products (will be inserted after user authentication is set up)
-- INSERT INTO public.products (product_name, category, supplier, quantity, unit_price, location, status)
-- VALUES 
--   ('Industrial Motor 5HP', 'Motors', 'ElectroSupply Inc', 10, 450.00, 'Warehouse A', 'active'),
--   ('Circuit Breaker 100A', 'Protection', 'SafeElectric Co', 25, 85.50, 'Warehouse B', 'active'),
--   ('LED Floodlight 200W', 'Lighting', 'BrightLight Ltd', 50, 120.00, 'Warehouse A', 'active'),
--   ('Cable 3-Core 16mm', 'Cables', 'WirePro Solutions', 500, 8.75, 'Storage Room 1', 'active'),
--   ('Distribution Board 12-Way', 'Panels', 'ElectroSupply Inc', 15, 225.00, 'Warehouse B', 'active');

-- Note: You can run this script or add your own sample data after setting up authentication
